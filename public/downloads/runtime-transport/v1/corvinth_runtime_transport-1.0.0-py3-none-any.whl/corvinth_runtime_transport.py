"""Optional transport for qualified Corvinth SDK 1.1.0, with no AWS access.

This module does not alter the installed SDK or its fingerprint identity.
Only readiness GETs may repeat. The SDK's processing POST is invoked once.
"""
from __future__ import annotations

import http.client
import json
import math
import ssl
import time


__version__ = "1.0.0"
PROTOCOL = "corvinth-runtime-v1"
READY_PATH = "/_corvinth/runtime/ready"


class StartupError(RuntimeError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def wait_ready(probe, *, timeout=180.0, clock=time.monotonic, sleep=time.sleep):
    """No image work is submitted by this function, including on uncertainty."""
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or not 0 < timeout <= 180:
        raise ValueError("invalid_startup_timeout")
    deadline = clock() + timeout
    while True:
        remaining = deadline - clock()
        if remaining <= 0:
            raise StartupError("runtime_startup_deadline")
        try:
            status, body = probe(min(5.0, remaining))
        except (OSError, http.client.HTTPException):
            status, body = 503, None
        if clock() >= deadline:
            raise StartupError("runtime_startup_deadline")
        if status in (401, 403):
            raise StartupError("runtime_access_denied")
        if status == 404:
            # Compatibility with a continuously available pre-handshake API.
            # This fallback does not claim that old deployments can wake.
            return "legacy"
        if status in (200, 202):
            if not isinstance(body, dict) or body.get("protocol") != PROTOCOL:
                raise StartupError("runtime_response_invalid")
            if status == 200 and body.get("state") == "ready":
                return "ready"
            if status != 202 or body.get("state") != "starting":
                raise StartupError("runtime_response_invalid")
        elif status not in (429, 502, 503, 504):
            raise StartupError("runtime_unavailable")
        sleep(min(2.0, max(0.0, deadline - clock())))


def https_probe(host, port, headers, timeout):
    connection = http.client.HTTPSConnection(host, port, timeout=timeout, context=ssl.create_default_context())
    try:
        connection.set_debuglevel(0)
        connection.request("GET", READY_PATH, headers={
            "Accept": "application/json", "Cache-Control": "no-store", **headers,
        })
        response = connection.getresponse()
        raw = response.read(4097)
        if len(raw) > 4096:
            raise StartupError("runtime_response_invalid")
        try:
            body = json.loads(raw)
        except (ValueError, UnicodeError):
            body = None
        return response.status, body
    finally:
        connection.close()


def _sdk_client():
    # Keep this import lazy so the same readiness transport can be vendored in
    # the relay without installing the native SDK in its Lambda runtime.
    from corvinth import Corvinth as QualifiedCorvinth

    class Corvinth(QualifiedCorvinth):
        def __init__(self, *, api_key, base_url, timeout=30.0, startup_timeout=180.0):
            super().__init__(api_key=api_key, base_url=base_url, timeout=timeout)
            if isinstance(startup_timeout, bool) or not isinstance(startup_timeout, (int, float)) or not math.isfinite(startup_timeout) or not 0 < startup_timeout <= 180:
                raise ValueError("invalid_startup_timeout")
            self.startup_timeout = startup_timeout

        def _post(self, wire, reference):
            wait_ready(lambda timeout: https_probe(self._host, self._port, {
                "X-API-Key": self._api_key,
                "User-Agent": "corvinth-runtime-transport/" + __version__,
            }, timeout), timeout=self.startup_timeout)
            # Never catch/replay errors from this call. Its uncertain-response
            # and exact replay contract remains owned by qualified SDK/API code.
            return super()._post(wire, reference)

    return Corvinth


def __getattr__(name):
    if name == "Corvinth":
        return _sdk_client()
    raise AttributeError(name)
