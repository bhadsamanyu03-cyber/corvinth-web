"""Customer-operated, restartable connector; standard AWS role credential chain.

Only an integration API credential and local durable journal are required.
No Corvinth staff secret, DynamoDB or Mongo privileges are used. Four local
slots overlap delivery; real admission remains controller/application-fenced.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import fcntl
import json
import os
from pathlib import Path
import signal
import threading
import time
from urllib.parse import urlsplit

import boto3
from botocore.config import Config
import httpx
from pulse_s3_connector import Connector, Transport, ConnectorError, transport_detail


def report(event):
    print(json.dumps(event, sort_keys=True), flush=True)


class Daemon:
    def __init__(self, connector, *, report=report):
        self.connector, self.report = connector, report
        self.stop = threading.Event()
        self.pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix='pulse-source')
        self.pending = set()
        self.scan = None
        self.owner_failure = None
        self.last_status = 0
        self.last_reference = 0

    def renew(self):
        while not self.stop.wait(20):
            if not self.scan: continue
            try:
                fresh = self.connector.claim()
                if not fresh or fresh['scan_id'] != self.scan:
                    # Pause/cancel/completion closes authority. Existing accepted
                    # work settles normally; no fresh submission is scheduled.
                    self.owner_failure = 'claim_closed'; continue
                self.connector.post('/v2/pulse/connectors/historical-scans/'+self.scan+'/compute-claim',
                    dict(connector_id=self.connector.connector_id))
            except Exception as exc:
                self.owner_failure = type(exc).__name__
                self.report(dict(event='connector_owner_lost', error_class=type(exc).__name__, causes=transport_detail(exc)))

    def tick(self):
        for future in list(self.pending):
            if future.done():
                # No blind transport replay. A process restart reclaims normal
                # authority; accepted executions are excluded by lease_items.
                future.result(); self.pending.remove(future)
        if self.owner_failure:
            if self.pending: return
            if self.owner_failure != 'claim_closed': raise ConnectorError('owner_renewal_failed')
            self.scan = None; self.owner_failure = None
        if time.monotonic()-self.last_status >= 20:
            from reference_connector import heartbeat
            heartbeat(self.connector); self.last_status=time.monotonic()
        if time.monotonic()-self.last_reference >= 20:
            from reference_connector import tick
            tick(self.connector);self.last_reference=time.monotonic()
        claim = self.connector.claim()
        if not claim:
            self.scan = None; return
        scan = claim['scan_id']
        if self.scan and self.scan != scan and self.pending:
            return  # Never mix a new scan with previous outstanding delivery.
        self.scan = scan
        if claim['discovery']['status'] != 'sealed': self.connector.capture(claim)
        plan = self.connector.post('/v2/pulse/connectors/historical-scans/'+scan+'/compute-claim',
            dict(connector_id=self.connector.connector_id))
        opened = [j for j in plan['children'] if j['status']=='active' and j['activation_admission']=='OPEN']
        if len(opened)>1: raise ConnectorError('multiple_open_compute_children')
        if not opened: return
        job = opened[0]
        if type(job.get('active_items')) is not int: raise ConnectorError('scheduling_projection_required')
        slots = max(0, 4-job['active_items']-len(self.pending))
        for _ in range(slots):
            if self.stop.is_set() or self.owner_failure: break
            self.pending.add(self.pool.submit(self.connector.execute_one, scan, job))

    def run(self, *, once=False):
        heartbeat = threading.Thread(target=self.renew, daemon=True); heartbeat.start()
        try:
            while not self.stop.is_set():
                self.tick()
                if once: break
                self.stop.wait(1)
        finally:
            self.stop.set()
            self.pool.shutdown(wait=True)
            heartbeat.join(timeout=95)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--once', action='store_true')
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text())
    origin = urlsplit(config['api_origin'])
    if origin.scheme != 'https' or origin.username or origin.password or origin.query or origin.fragment or origin.path not in ('','/'):
        raise ConnectorError('https_origin_required')
    root = Path(config['journal_root']); root.mkdir(parents=True, exist_ok=True)
    lock = (root/'connector.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
    key = Path(os.environ['CORVINTH_API_KEY_FILE']).read_text().strip()
    session = boto3.Session(region_name=config['region'])
    s3 = session.client('s3', config=Config(signature_version='s3v4',connect_timeout=5,read_timeout=30,retries={'total_max_attempts':2}))
    with httpx.Client(base_url=config['api_origin'], headers={'x-api-key':key}, timeout=90,
            trust_env=False, follow_redirects=False, transport=httpx.HTTPTransport(retries=0)) as client:
        connector = Connector(s3=s3, api=Transport(client,evidence=report), api_origin=config['api_origin'],
            journal_root=root, integration_id=config['integration_id'], prefix=config['prefix'],
            connector_id=config['connector_id'])
        daemon = Daemon(connector)
        for name in (signal.SIGTERM,signal.SIGINT): signal.signal(name,lambda *_:daemon.stop.set())
        daemon.run(once=args.once)


if __name__=='__main__':
    try: main()
    except Exception as exc:
        report(dict(event='connector_stopped',error_class=type(exc).__name__,causes=transport_detail(exc)))
        raise SystemExit(1) from None
