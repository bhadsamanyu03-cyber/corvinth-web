"""Customer JIT reference delivery, reconciled by durable preparation identity."""
from pulse_s3_connector import ConnectorTransportError


def tick(connector):
    claim=connector.post('/v2/pulse/connectors/reference-preparations/claim',dict(
        connector_id=connector.connector_id,storage_integration_id=connector.integration_id,
        selected_prefix=connector.prefix))
    if not claim:return False
    if not claim['admitted'] or claim['status']!='bound':return False
    ref=claim['storage_reference']
    params=dict(Bucket=ref['storage_bucket'],Key=ref['object_key'])
    if ref['object_version'] is not None:params['VersionId']=ref['object_version']
    # No signing before ledger admission. Never log or journal this URL.
    url=connector.s3.generate_presigned_url('get_object',Params=params,ExpiresIn=300)
    try:
        connector.post('/v2/pulse/connectors/reference-preparations/'+claim['preparation_id']+'/execute',
            dict(connector_id=connector.connector_id,presigned_url=url))
    except ConnectorTransportError:
        # The next claim reconciles the same durable at-most-once acceptance;
        # it never creates another complaint or bypasses accepted work.
        pass
    return True


def heartbeat(connector):
    return connector.post('/v2/pulse/connectors/status',dict(connector_id=connector.connector_id,
        storage_integration_id=connector.integration_id,selected_prefix=connector.prefix,
        capabilities=['historical_scan_v1','reference_preparation_v1']))
