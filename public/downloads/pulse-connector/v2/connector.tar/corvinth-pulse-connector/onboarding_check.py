"""Run as the connector service user: scoped read-only preflight, no GPU work."""
import argparse
import json
import os
from pathlib import Path
from urllib.parse import urlsplit

import boto3
from botocore.config import Config
import httpx


def check(config, key, *, http, session):
    # No redirects or proxy environment may forward the platform credential.
    tenant=http.get(config['api_origin'].rstrip('/')+'/platform/verify',headers={'X-API-Key':key})
    tenant.raise_for_status();tenant=tenant.json()
    if tenant.get('status')!='active' or tenant.get('platform_id')!=config['platform_id']:
        raise ValueError('credential_platform_mismatch')
    result=http.get(config['api_origin'].rstrip('/')+'/console/v1/pulse/setup',headers={'X-API-Key':key})
    result.raise_for_status()
    rows=[r for r in result.json()['integrations'] if r['id']==config['integration_id']]
    if len(rows)!=1 or not rows[0]['pulse_eligible'] or rows[0]['approved_prefix']!=config['prefix']:
        raise ValueError('registered_scope_not_eligible')
    row=rows[0]
    if row['bucket_region']!=config['region']:raise ValueError('registered_region_mismatch')
    identity=session.client('sts',config=Config(retries={'max_attempts':0})).get_caller_identity()
    if identity['Arn'].endswith(':root'):raise ValueError('customer_root_credentials_not_supported')
    s3=session.client('s3',config=Config(retries={'max_attempts':0},signature_version='s3v4'))
    versioning=s3.get_bucket_versioning(Bucket=row['storage_bucket']).get('Status')
    versioned=row['version_policy']=='versioned'
    if versioned and versioning!='Enabled':raise ValueError('bucket_version_policy_mismatch')
    params={'Bucket':row['storage_bucket'],'Prefix':config['prefix'],'MaxKeys':1}
    listing=s3.list_object_versions(**params) if versioned else s3.list_objects_v2(**params)
    sample=listing.get('Versions' if versioned else 'Contents',[])
    if sample:
        head={'Bucket':row['storage_bucket'],'Key':sample[0]['Key']}
        if versioned:head['VersionId']=sample[0]['VersionId']
        metadata=s3.head_object(**head)
        if versioned and metadata.get('VersionId')!=head['VersionId']:raise ValueError('object_version_mismatch')
    return {'status':'PASS','platform_verified':True,'registered_scope_verified':True,
        'scoped_listing_verified':True,'sample_metadata_verified':bool(sample),
        'source_bytes_fetched':0,'gpu_activated':False,
        'note':'An empty scope cannot prove object access. SSE-KMS objects also require the customer role to decrypt the approved key.'}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--config',required=True);parser.add_argument('--platform-id',required=True)
    args=parser.parse_args();config=json.loads(Path(args.config).read_text());config['platform_id']=args.platform_id
    u=urlsplit(config['api_origin'])
    if u.scheme!='https' or u.username or u.password or u.query or u.fragment or u.path not in ('','/'):
        raise ValueError('https_origin_required')
    key=Path(os.environ['CORVINTH_API_KEY_FILE']).read_text().strip()
    with httpx.Client(timeout=15,trust_env=False,follow_redirects=False) as http:
        result=check(config,key,http=http,session=boto3.Session(region_name=config['region']))
    print(json.dumps(result,sort_keys=True))


if __name__=='__main__':
    try:main()
    except Exception as exc:
        # Transport/native exceptions can contain credentials, URLs or object names.
        print(json.dumps({'status':'FAIL','stage':'customer_connector_preflight','error_class':type(exc).__name__,
            'error_code':str(exc) if isinstance(exc,ValueError) else 'inspect_customer_role_and_registered_scope'}))
        raise SystemExit(1) from None
