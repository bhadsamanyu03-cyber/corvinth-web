"""Pure S3 listing validation reused from the customer enumerator.

No quiescence, snapshot, journal or Shield admission semantics are imported.
"""
from __future__ import annotations
import re
from urllib.parse import unquote
import storage_identity_contract as c

class EnumerationError(RuntimeError):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)

def _decoded(value):
    # EncodingType is explicitly requested, so botocore leaves these encoded.
    # Decode once, preserving literal '+', '%', slash and Unicode key identity.
    if not isinstance(value, str) or re.search(r"%(?![0-9a-fA-F]{2})", value):
        raise EnumerationError("invalid_s3_key_encoding")
    try:
        return unquote(value, encoding="utf-8", errors="strict")
    except UnicodeError:
        raise EnumerationError("invalid_s3_key_encoding") from None

def _opaque(value):
    if not isinstance(value, str) or not value:
        raise EnumerationError("invalid_s3_pagination_marker")
    value.encode("utf-8", errors="strict")
    return value

def normalize_page(preflight, response: dict, page_size: int):
    """Retain only listing authority, never an arbitrary AWS response payload."""
    if not isinstance(response, dict):
        raise EnumerationError("s3_listing_response_invalid")
    scope = preflight.scope
    versioned = preflight.listing_method == "ListObjectVersions"
    if (response.get("Name") != scope.integration.storage_bucket
            or response.get("EncodingType") != "url"
            or _decoded(response.get("Prefix")) != scope.selected_prefix
            or type(response.get("IsTruncated")) is not bool
            or response.get("CommonPrefixes") or response.get("Delimiter")):
        raise EnumerationError("s3_listing_scope_or_shape_invalid")
    groups = (("Versions", "version"), ("DeleteMarkers", "delete")) if versioned else (("Contents", "version"),)
    if any(response.get(field) for field in (("Contents",) if versioned else ("Versions", "DeleteMarkers"))):
        raise EnumerationError("s3_listing_method_mismatch")
    rows = []
    for field, kind in groups:
        entries = response.get(field, [])
        if not isinstance(entries, list):
            raise EnumerationError("s3_listing_entries_invalid")
        for entry in entries:
            if not isinstance(entry, dict):
                raise EnumerationError("s3_listing_entry_invalid")
            key = _decoded(entry.get("Key"))
            c.validate_object_key(key)
            if not key.startswith(scope.selected_prefix):
                raise EnumerationError("s3_listing_outside_scope")
            latest = entry.get("IsLatest") if versioned else True
            if type(latest) is not bool:
                raise EnumerationError("s3_listing_latest_missing")
            version = _opaque(entry.get("VersionId")) if versioned else ""
            if versioned and version != "null":
                c.validate_object_version(version)
            rows.append([key, version, kind, latest])
    if len(rows) > page_size:
        raise EnumerationError("s3_listing_page_limit_exceeded")
    if not versioned and "KeyCount" in response and (
            type(response["KeyCount"]) is not int or response["KeyCount"] != len(rows)):
        raise EnumerationError("s3_listing_key_count_mismatch")
    truncated = response["IsTruncated"]
    cursor = {}
    if truncated:
        if not rows:
            raise EnumerationError("s3_empty_truncated_page")
        if versioned:
            cursor = {"KeyMarker": _decoded(_opaque(response.get("NextKeyMarker"))),
                      "VersionIdMarker": _opaque(response.get("NextVersionIdMarker"))}
            if not cursor["KeyMarker"].startswith(scope.selected_prefix):
                raise EnumerationError("s3_pagination_marker_outside_scope")
        else:
            cursor = {"ContinuationToken": _opaque(response.get("NextContinuationToken"))}
    elif any(response.get(field) is not None for field in (
            "NextKeyMarker", "NextVersionIdMarker", "NextContinuationToken")):
        raise EnumerationError("s3_terminal_page_has_cursor")
    return {"entries": sorted(rows), "next_cursor": cursor, "complete": not truncated}
