"""Pure storage_identity_v1 contracts and deterministic identity helpers.

This module intentionally performs no database, network, route, worker, relay,
or environment access. Runtime authority and persistence are later SI passes.
"""

from __future__ import annotations

import base64
import hashlib
import ipaddress
import json
import math
import re
import struct
import uuid
from collections.abc import Mapping
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Annotated, Any, Literal, Sequence, TypeAlias
from urllib.parse import unquote_to_bytes, urlsplit

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, field_validator, model_validator


INTEGRATION_CONTRACT_VERSION = "storage_identity_v1"
STORAGE_IDENTITY_MIGRATION_MARKER_ID = "storage_identity_v1"
STORAGE_IDENTITY_MIGRATION_COMPLETE_STATUS = "migration_complete"
STORAGE_IDENTITY_RUNTIME_FLAG = "STORAGE_IDENTITY_V1_ENABLED"
SUPPORTED_SDK_MAJORS = frozenset({1})
COLLECTION_MANIFEST_VERSION = 1
INDEX_MANIFEST_VERSION = 1
QDRANT_MANIFEST_VERSION = 1
SIGNAL_ARTIFACT_MANIFEST_VERSION = 1
QDRANT_COLLECTION_GENERATION_PREFIX = "qdrantgen:v1:"
QDRANT_COLLECTION_NAME_PREFIX = "corvinth_pulse_library_v2_"
QDRANT_ALIAS_NAME = "corvinth_pulse_library_v2"
QDRANT_VECTOR_NAME = "dino"
QDRANT_VECTOR_SIZE = 384
QDRANT_DISTANCE = "Cosine"
QDRANT_DATATYPE = "float32"
QDRANT_ON_DISK = False
QDRANT_PAYLOAD_INDEX_SCHEMA = {
    "platform_id": "keyword",
    "corpus_kind": "keyword",
    "corpus_id": "keyword",
    "storage_identity_key": "keyword",
}
QDRANT_PAYLOAD_FIELDS = (
    "platform_id",
    "corpus_kind",
    "corpus_id",
    "storage_identity_key",
    "signal_binding_id",
    "algorithm_version",
    "model_version",
    "configuration_version",
    "signal_fingerprint",
)
QDRANT_HNSW_CONFIG = {
    "m": 16,
    "ef_construct": 100,
    "full_scan_threshold": 10000,
    "max_indexing_threads": 0,
    "on_disk": False,
    "payload_m": None,
}
PULSE_LIBRARY_CORPUS_KIND = "pulse_library"
PULSE_LIBRARY_CORPUS_ID = "primary_library"
BACKFILL_JOB_MAX_ITEMS = {
    "pulse_library": 100_000,
    "complaint_scan": 50_000,
}
BACKFILL_REGISTRATION_PAGE_MAX_ITEMS = 500
BACKFILL_LEASE_BATCH_MAX_ITEMS = 50
BACKFILL_ATTEMPT_LIMIT = 5
BACKFILL_LEASE_SECONDS = 180
BACKFILL_HEARTBEAT_SECONDS = 30
BACKFILL_LEASE_MAX_SECONDS = 600
STORAGE_ACTION_EVENT_TYPE = "match.detected"
STORAGE_ACTION_WEBHOOK_CONTRACT_VERSION = "storage_action_v1"
STORAGE_ACTION_REQUESTED_ACTION = "remove_content"
MINIMUM_STORAGE_IDENTITY_COLLECTIONS = frozenset({
    "schema_migrations",
    "platform_archive",
    "platform_storage_integrations",
    "platform_storage_objects",
    "platform_storage_signal_bindings",
    "storage_backfill_jobs",
    "storage_backfill_items",
    "storage_backfill_executions",
    "storage_backfill_registration_effects",
    "storage_result_outbox",
    "pulse_threshold_profiles",
})

_LOWER_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_HASH64_RE = re.compile(r"^[0-9a-fA-F]{64}$")
_BUCKET_RE = re.compile(r"^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$")
_REGION_RE = re.compile(r"^[a-z0-9-]+$")
_PERCENT_ESCAPE_RE = re.compile(r"%(?![0-9A-Fa-f]{2})")
_SIGNATURE_RE = re.compile(r"^[0-9a-f]{64}$")
_QDRANT_GENERATION_RE = re.compile(r"^qdrantgen:v1:([0-9a-f]{32})$")
_BACKFILL_CLIENT_ID_RE = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")
_SEMVER_RE = re.compile(
    r"^(0|[1-9][0-9]*)\."
    r"(0|[1-9][0-9]*)\."
    r"(0|[1-9][0-9]*)"
    r"(?:-((?:0|[1-9][0-9]*|[0-9]*[A-Za-z-][0-9A-Za-z-]*)"
    r"(?:\.(?:0|[1-9][0-9]*|[0-9]*[A-Za-z-][0-9A-Za-z-]*))*))?"
    r"(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$"
)
_UNRESERVED_BYTES = frozenset(
    b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"
)


class StorageIdentityContractError(ValueError):
    """A sanitized, stable pure-contract failure."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


class _FrozenContractModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


StrictContractStr = Annotated[str, Field(strict=True)]
PositiveContractInt = Annotated[int, Field(strict=True, ge=1)]
NonNegativeContractInt = Annotated[int, Field(strict=True, ge=0)]


class StorageProvider(str, Enum):
    S3 = "s3"


class VersionPolicy(str, Enum):
    VERSIONED = "versioned"
    IMMUTABLE_KEYS = "immutable_keys"


class ContentFingerprintProvenance(str, Enum):
    CORVINTH_COMPUTED = "corvinth_computed"
    PLATFORM_ASSERTED = "platform_asserted"


class SignalDerivationSource(str, Enum):
    CORVINTH_COMPUTED = "corvinth_computed"
    PLATFORM_ASSERTED = "platform_asserted"


class CorpusKind(str, Enum):
    PULSE_LIBRARY = "pulse_library"
    COMPLAINT_SCAN = "complaint_scan"
    SHIELD_ARCHIVE = "shield_archive"


class OutboxProducerKind(str, Enum):
    SYNCHRONOUS_SIGNAL_BINDING = "synchronous_signal_binding"
    BACKFILL_ITEM = "backfill_item"
    COMPLAINT_SCAN_COMPLETION = "complaint_scan_completion"
    CASE_ACTION = "case_action"


class OutboxEffectKind(str, Enum):
    QDRANT_LIBRARY_UPSERT = "qdrant_library_upsert"
    COMPLAINT_SCAN_COMPLETE_WEBHOOK = "complaint_scan_complete_webhook"
    STORAGE_ACTION_WEBHOOK = "storage_action_webhook"


class OutboxAuthorityKind(str, Enum):
    SIGNAL_BINDING = "signal_binding"
    BACKFILL_ITEM = "backfill_item"
    COMPLAINT_SCAN_COMPLETION = "complaint_scan_completion"
    CASE_ACTION = "case_action"


OUTBOX_LAST_ERROR_CODES = frozenset({
    "producer_authority_missing",
    "producer_authority_mismatch",
    "result_digest_mismatch",
    "intent_digest_mismatch",
    "unsupported_producer_effect",
    "destination_generation_mismatch",
    "qdrant_timeout",
    "qdrant_rate_limited",
    "qdrant_transport_error",
    "qdrant_server_error",
    "qdrant_acknowledgement_unknown",
    "qdrant_readback_unavailable",
    "qdrant_manifest_mismatch",
    "qdrant_collection_missing",
    "qdrant_alias_mismatch",
    "qdrant_schema_mismatch",
    "qdrant_point_readback_missing",
    "qdrant_point_readback_mismatch",
    "qdrant_vector_digest_mismatch",
    "qdrant_payload_mismatch",
    "webhook_configuration_read_failed",
    "webhook_dns_resolution_failed",
    "webhook_platform_missing",
    "webhook_platform_inactive",
    "webhook_url_missing",
    "webhook_secret_missing",
    "webhook_destination_invalid",
    "webhook_destination_policy_rejected",
    "webhook_connect_timeout",
    "webhook_read_timeout",
    "webhook_transport_error",
    "webhook_http_408",
    "webhook_http_425",
    "webhook_http_429",
    "webhook_http_5xx",
    "webhook_remote_rejected",
    "webhook_payload_digest_mismatch",
    "webhook_event_authority_mismatch",
    "webhook_signature_configuration_invalid",
})
OUTBOX_RETRYABLE_ERROR_CODES = frozenset({
    "qdrant_timeout",
    "qdrant_rate_limited",
    "qdrant_transport_error",
    "qdrant_server_error",
    "qdrant_acknowledgement_unknown",
    "qdrant_readback_unavailable",
    "webhook_configuration_read_failed",
    "webhook_dns_resolution_failed",
    "webhook_platform_missing",
    "webhook_platform_inactive",
    "webhook_url_missing",
    "webhook_secret_missing",
    "webhook_destination_invalid",
    "webhook_destination_policy_rejected",
    "webhook_connect_timeout",
    "webhook_read_timeout",
    "webhook_transport_error",
    "webhook_http_408",
    "webhook_http_425",
    "webhook_http_429",
    "webhook_http_5xx",
    "webhook_remote_rejected",
})


def _json_value_v1(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, (list, tuple)):
        return [_json_value_v1(item) for item in value]
    if value is None or isinstance(value, (bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise StorageIdentityContractError("canonical_json_non_finite_number")
        return value
    if isinstance(value, str):
        try:
            value.encode("utf-8")
        except UnicodeEncodeError as exc:
            raise StorageIdentityContractError("canonical_json_unpaired_surrogate") from exc
        return value
    raise StorageIdentityContractError("canonical_json_unsupported_type")


def canonical_json_array_v1(value: Sequence[Any]) -> bytes:
    """Encode the frozen RFC 8259 array/scalar deterministic-ID preimage."""

    if not isinstance(value, (list, tuple)):
        raise StorageIdentityContractError("canonical_json_root_must_be_array")
    normalized = _json_value_v1(value)
    try:
        rendered = json.dumps(
            normalized,
            ensure_ascii=False,
            separators=(",", ":"),
            allow_nan=False,
        )
        return rendered.encode("utf-8")
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise StorageIdentityContractError("canonical_json_encoding_failed") from exc


def _deterministic_id(prefix: str, preimage: Sequence[Any]) -> str:
    digest = hashlib.sha256(canonical_json_array_v1(preimage)).hexdigest()
    return f"{prefix}{digest}"


def _utf8_sort_key(value: str) -> bytes:
    _validate_exact_nonempty_string(value, "invalid_manifest_string")
    return value.encode("utf-8")


def _validated_lower_sha256(value: str, code: str) -> str:
    if not isinstance(value, str) or not _LOWER_SHA256_RE.fullmatch(value):
        raise StorageIdentityContractError(code)
    return value


def canonical_bson_value_v1(value: Any) -> list[Any]:
    if value is None:
        return ["null"]
    if isinstance(value, bool):
        return ["bool", value]
    if isinstance(value, str):
        try:
            value.encode("utf-8")
        except UnicodeEncodeError as exc:
            raise StorageIdentityContractError(
                "invalid_canonical_bson_string"
            ) from exc
        return ["string", value]
    if isinstance(value, int):
        return ["int", str(value)]
    if isinstance(value, float):
        if not math.isfinite(value):
            raise StorageIdentityContractError("canonical_bson_non_finite_float")
        if value == 0.0:
            value = 0.0
        return ["float64", struct.pack(">d", value).hex()]
    if isinstance(value, (list, tuple)):
        return ["array", [canonical_bson_value_v1(item) for item in value]]
    if isinstance(value, Mapping):
        entries: list[list[Any]] = []
        seen: set[str] = set()
        for key, item in value.items():
            if not isinstance(key, str) or key in seen:
                raise StorageIdentityContractError("invalid_canonical_bson_document")
            _validate_exact_nonempty_string(key, "invalid_canonical_bson_document")
            seen.add(key)
            entries.append([key, canonical_bson_value_v1(item)])
        entries.sort(key=lambda entry: entry[0].encode("utf-8"))
        return ["document", entries]
    raise StorageIdentityContractError("unsupported_canonical_bson_type")


def storage_collection_manifest_v1(entries: Sequence[tuple[str, bytes | str]]) -> tuple[list[Any], str]:
    canonical: list[list[str]] = []
    seen: set[str] = set()
    for collection_name, physical_uuid in entries:
        _validate_exact_nonempty_string(collection_name, "invalid_collection_name")
        if collection_name in seen:
            raise StorageIdentityContractError("duplicate_collection_name")
        seen.add(collection_name)
        if isinstance(physical_uuid, bytes):
            if len(physical_uuid) != 16:
                raise StorageIdentityContractError("invalid_collection_uuid")
            uuid_hex = physical_uuid.hex()
        elif isinstance(physical_uuid, str):
            uuid_hex = physical_uuid
        else:
            raise StorageIdentityContractError("invalid_collection_uuid")
        if not re.fullmatch(r"[0-9a-f]{32}", uuid_hex):
            raise StorageIdentityContractError("invalid_collection_uuid")
        canonical.append([collection_name, uuid_hex])
    if not MINIMUM_STORAGE_IDENTITY_COLLECTIONS.issubset(seen):
        raise StorageIdentityContractError("incomplete_collection_manifest")
    canonical.sort(key=lambda entry: entry[0].encode("utf-8"))
    envelope = ["storage-collection-manifest:v1", 1, canonical]
    return envelope, _deterministic_id("storage-collection-manifest:v1:", envelope)


def storage_index_manifest_v1(entries: Sequence[Mapping[str, Any]]) -> tuple[list[Any], str]:
    canonical: list[list[Any]] = []
    seen: set[tuple[str, str]] = set()
    allowed_specs = {1, -1, "hashed"}
    for raw in entries:
        collection = raw.get("collection")
        index_name = raw.get("index_name")
        _validate_exact_nonempty_string(collection, "invalid_index_manifest_entry")
        _validate_exact_nonempty_string(index_name, "invalid_index_manifest_entry")
        identity = (collection, index_name)
        if identity in seen:
            raise StorageIdentityContractError("duplicate_index_manifest_entry")
        seen.add(identity)
        keys = raw.get("keys")
        if not isinstance(keys, (list, tuple)) or not keys:
            raise StorageIdentityContractError("invalid_index_key_spec")
        canonical_keys: list[list[Any]] = []
        for key_name, key_spec in keys:
            _validate_exact_nonempty_string(key_name, "invalid_index_key_spec")
            if key_spec not in allowed_specs or isinstance(key_spec, bool):
                raise StorageIdentityContractError("unsupported_index_key_spec")
            canonical_keys.append([key_name, key_spec])
        expire = raw.get("expireAfterSeconds")
        if expire is not None and (isinstance(expire, bool) or not isinstance(expire, int)):
            raise StorageIdentityContractError("invalid_index_expiry")
        for option_name in ("unique", "sparse", "hidden"):
            if option_name in raw and not isinstance(raw[option_name], bool):
                raise StorageIdentityContractError("invalid_index_boolean_option")
        canonical.append([
            collection,
            index_name,
            canonical_keys,
            raw.get("unique", False),
            None if raw.get("partialFilterExpression") is None else canonical_bson_value_v1(raw["partialFilterExpression"]),
            raw.get("sparse", False),
            expire,
            None if raw.get("collation") is None else canonical_bson_value_v1(raw["collation"]),
            raw.get("hidden", False),
        ])
    canonical.sort(key=lambda entry: (entry[0].encode("utf-8"), entry[1].encode("utf-8")))
    envelope = ["storage-index-manifest:v1", 1, canonical]
    return envelope, _deterministic_id("storage-index-manifest:v1:", envelope)


def storage_qdrant_manifest_v1(
    *, collection_name: str, collection_generation: str, alias_name: str,
    vector_name: str, vector_size: int, distance: str, datatype: str,
    on_disk: bool, payload_schema: Mapping[str, Any],
    quantization_config: Any = None, hnsw_config: Any = None,
) -> tuple[list[Any], str]:
    expected_collection = qdrant_collection_name_v2(collection_generation)
    if (
        collection_name != expected_collection
        or alias_name != QDRANT_ALIAS_NAME
        or vector_name != QDRANT_VECTOR_NAME
        or vector_size != QDRANT_VECTOR_SIZE
        or distance != QDRANT_DISTANCE
        or datatype != QDRANT_DATATYPE
        or on_disk is not QDRANT_ON_DISK
        or dict(payload_schema) != QDRANT_PAYLOAD_INDEX_SCHEMA
        or quantization_config is not None
        or hnsw_config != QDRANT_HNSW_CONFIG
    ):
        raise StorageIdentityContractError("invalid_qdrant_manifest")
    manifest = [
        "storage-qdrant-manifest",
        collection_generation,
        collection_name,
        alias_name,
        [
            "vector",
            QDRANT_VECTOR_NAME,
            QDRANT_VECTOR_SIZE,
            QDRANT_DISTANCE,
            QDRANT_DATATYPE,
            QDRANT_ON_DISK,
        ],
        [
            "payload_indexes",
            ["platform_id", "keyword"],
            ["corpus_kind", "keyword"],
            ["corpus_id", "keyword"],
            ["storage_identity_key", "keyword"],
        ],
        ["payload_fields", *QDRANT_PAYLOAD_FIELDS],
        ["quantization_config", None],
        [
            "hnsw_config",
            QDRANT_HNSW_CONFIG["m"],
            QDRANT_HNSW_CONFIG["ef_construct"],
            QDRANT_HNSW_CONFIG["full_scan_threshold"],
            QDRANT_HNSW_CONFIG["max_indexing_threads"],
            QDRANT_HNSW_CONFIG["on_disk"],
            QDRANT_HNSW_CONFIG["payload_m"],
        ],
    ]
    digest = hashlib.sha256(canonical_json_array_v1(manifest)).hexdigest()
    return manifest, f"storage-qdrant-manifest:v1:{digest}"


def qdrant_collection_name_v2(collection_generation: str) -> str:
    if not isinstance(collection_generation, str):
        raise StorageIdentityContractError("invalid_qdrant_collection_generation")
    match = _QDRANT_GENERATION_RE.fullmatch(collection_generation)
    if match is None:
        raise StorageIdentityContractError("invalid_qdrant_collection_generation")
    return f"{QDRANT_COLLECTION_NAME_PREFIX}{match.group(1)}"


def qdrant_manifest_from_generation_v1(
    collection_generation: str,
) -> tuple[list[Any], str]:
    return storage_qdrant_manifest_v1(
        collection_name=qdrant_collection_name_v2(collection_generation),
        collection_generation=collection_generation,
        alias_name=QDRANT_ALIAS_NAME,
        vector_name=QDRANT_VECTOR_NAME,
        vector_size=QDRANT_VECTOR_SIZE,
        distance=QDRANT_DISTANCE,
        datatype=QDRANT_DATATYPE,
        on_disk=QDRANT_ON_DISK,
        payload_schema=QDRANT_PAYLOAD_INDEX_SCHEMA,
        quantization_config=None,
        hnsw_config=QDRANT_HNSW_CONFIG,
    )


def validate_qdrant_manifest_v1(
    manifest: Any,
    manifest_digest: str,
) -> dict[str, Any]:
    if not isinstance(manifest, list) or len(manifest) < 2:
        raise StorageIdentityContractError("invalid_qdrant_manifest")
    generation = manifest[1]
    expected_manifest, expected_digest = qdrant_manifest_from_generation_v1(
        generation
    )
    if manifest != expected_manifest or manifest_digest != expected_digest:
        raise StorageIdentityContractError("invalid_qdrant_manifest")
    return {
        "collection_generation": generation,
        "collection_name": expected_manifest[2],
        "alias_name": QDRANT_ALIAS_NAME,
        "vector_name": QDRANT_VECTOR_NAME,
    }


def storage_signal_artifact_manifest_v1(
    artifacts: Sequence[tuple[str, str, str]],
    golden_fixtures: Sequence[tuple[str, str, str]],
) -> tuple[list[Any], str]:
    artifact_rows: list[list[str]] = []
    seen_artifacts: set[tuple[str, str]] = set()
    for role, identifier, digest in artifacts:
        identity = (role, identifier)
        if identity in seen_artifacts:
            raise StorageIdentityContractError("duplicate_signal_artifact")
        seen_artifacts.add(identity)
        _utf8_sort_key(role); _utf8_sort_key(identifier)
        artifact_rows.append([role, identifier, _validated_lower_sha256(digest, "invalid_signal_artifact_digest")])
    fixture_rows: list[list[str]] = []
    seen_fixtures: set[str] = set()
    for fixture_id, fixture_digest, expected_digest in golden_fixtures:
        if fixture_id in seen_fixtures:
            raise StorageIdentityContractError("duplicate_golden_fixture")
        seen_fixtures.add(fixture_id); _utf8_sort_key(fixture_id)
        fixture_rows.append([fixture_id, _validated_lower_sha256(fixture_digest, "invalid_golden_fixture_digest"), _validated_lower_sha256(expected_digest, "invalid_golden_output_digest")])
    artifact_rows.sort(key=lambda row: (row[0].encode("utf-8"), row[1].encode("utf-8")))
    fixture_rows.sort(key=lambda row: row[0].encode("utf-8"))
    envelope = ["storage-signal-artifacts:v1", 1, artifact_rows, fixture_rows]
    return envelope, _deterministic_id("storage-signal-artifacts:v1:", envelope)


def pdq_golden_output_digest_v1(
    standard_pairs: Sequence[tuple[str, str]], normalized_pairs: Sequence[tuple[str, str]],
) -> str:
    def lane(values: Sequence[tuple[str, str]]) -> list[list[str]]:
        rows = [[kind, _validate_pdq_hash(value)] for kind, value in values]
        rows.sort(key=lambda row: (row[0], row[1]))
        return rows
    return hashlib.sha256(canonical_json_array_v1([
        "storage-pdq-golden-output:v1", lane(standard_pairs), lane(normalized_pairs)
    ])).hexdigest()


def _validate_exact_nonempty_string(value: str, code: str) -> str:
    if not isinstance(value, str) or not value:
        raise StorageIdentityContractError(code)
    try:
        value.encode("utf-8")
    except UnicodeEncodeError as exc:
        raise StorageIdentityContractError(code) from exc
    return value


def validate_s3_bucket(value: str) -> str:
    if not isinstance(value, str) or not _BUCKET_RE.fullmatch(value):
        raise StorageIdentityContractError("invalid_storage_bucket")
    if ".." in value:
        raise StorageIdentityContractError("invalid_storage_bucket")
    try:
        ipaddress.ip_address(value)
    except ValueError:
        pass
    else:
        raise StorageIdentityContractError("invalid_storage_bucket")
    return value


def validate_bucket_region(value: str) -> str:
    if not isinstance(value, str) or not value or not _REGION_RE.fullmatch(value):
        raise StorageIdentityContractError("invalid_bucket_region")
    return value


def validate_object_key(value: str) -> str:
    if not isinstance(value, str):
        raise StorageIdentityContractError("invalid_object_key")
    try:
        encoded = value.encode("utf-8")
    except UnicodeEncodeError as exc:
        raise StorageIdentityContractError("invalid_object_key") from exc
    if not 1 <= len(encoded) <= 1024:
        raise StorageIdentityContractError("invalid_object_key")
    if any(segment in {".", ".."} for segment in value.split("/")):
        raise StorageIdentityContractError("unsupported_object_key_dot_segment")
    return value


def validate_object_version(value: str | None) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value or value == "null":
        raise StorageIdentityContractError("invalid_object_version")
    try:
        encoded = value.encode("utf-8")
    except UnicodeEncodeError as exc:
        raise StorageIdentityContractError("invalid_object_version") from exc
    if len(encoded) > 1024:
        raise StorageIdentityContractError("invalid_object_version")
    return value


class StorageIntegrationV1(_FrozenContractModel):
    schema_version: Literal[1] = 1
    platform_id: StrictContractStr
    storage_provider: Literal["s3"] = "s3"
    storage_bucket: StrictContractStr
    bucket_region: StrictContractStr
    version_policy: VersionPolicy
    configuration_version: PositiveContractInt

    @field_validator("platform_id")
    @classmethod
    def _platform_id(cls, value: str) -> str:
        return _validate_exact_nonempty_string(value, "invalid_platform_id")

    @field_validator("storage_bucket")
    @classmethod
    def _bucket(cls, value: str) -> str:
        return validate_s3_bucket(value)

    @field_validator("bucket_region")
    @classmethod
    def _region(cls, value: str) -> str:
        return validate_bucket_region(value)

    @property
    def storage_integration_id(self) -> str:
        return storage_integration_id(
            self.platform_id,
            self.storage_bucket,
            self.configuration_version,
        )

    @property
    def configuration_digest(self) -> str:
        return storage_integration_configuration_digest(
            self.platform_id,
            self.storage_bucket,
            self.bucket_region,
            self.version_policy,
        )


class StorageObjectReferenceV1(_FrozenContractModel):
    type: Literal["storage_object"] = "storage_object"
    storage_provider: Literal["s3"] = "s3"
    storage_bucket: StrictContractStr
    object_key: StrictContractStr
    object_version: StrictContractStr | None

    @field_validator("storage_bucket")
    @classmethod
    def _bucket(cls, value: str) -> str:
        return validate_s3_bucket(value)

    @field_validator("object_key")
    @classmethod
    def _key(cls, value: str) -> str:
        return validate_object_key(value)

    @field_validator("object_version")
    @classmethod
    def _version(cls, value: str | None) -> str | None:
        return validate_object_version(value)


def validate_reference_for_integration(
    reference: StorageObjectReferenceV1,
    integration: StorageIntegrationV1,
) -> None:
    if reference.storage_provider != integration.storage_provider:
        raise StorageIdentityContractError("storage_provider_mismatch")
    if reference.storage_bucket != integration.storage_bucket:
        raise StorageIdentityContractError("storage_bucket_mismatch")
    if integration.version_policy is VersionPolicy.VERSIONED:
        if reference.object_version is None:
            raise StorageIdentityContractError("versioned_object_version_required")
    elif integration.version_policy is VersionPolicy.IMMUTABLE_KEYS:
        if reference.object_version is not None:
            raise StorageIdentityContractError("immutable_key_object_version_must_be_null")
    else:  # pragma: no cover - enum prevents this, retained as fail-closed authority.
        raise StorageIdentityContractError("unknown_version_policy")


def storage_integration_id(
    platform_id: str,
    storage_bucket: str,
    configuration_version: int,
) -> str:
    _validate_exact_nonempty_string(platform_id, "invalid_platform_id")
    validate_s3_bucket(storage_bucket)
    if isinstance(configuration_version, bool) or not isinstance(configuration_version, int) or configuration_version < 1:
        raise StorageIdentityContractError("invalid_configuration_version")
    return _deterministic_id(
        "storage-integration:v1:",
        [
            "storage-integration-id:v1",
            platform_id,
            "s3",
            storage_bucket,
            configuration_version,
        ],
    )


def storage_integration_configuration_digest(
    platform_id: str,
    storage_bucket: str,
    bucket_region: str,
    version_policy: VersionPolicy | str,
) -> str:
    _validate_exact_nonempty_string(platform_id, "invalid_platform_id")
    validate_s3_bucket(storage_bucket)
    validate_bucket_region(bucket_region)
    try:
        policy = VersionPolicy(version_policy).value
    except ValueError as exc:
        raise StorageIdentityContractError("unknown_version_policy") from exc
    return _deterministic_id(
        "storage-integration-config:v1:",
        [
            "storage-integration-config:v1",
            INTEGRATION_CONTRACT_VERSION,
            platform_id,
            "s3",
            storage_bucket,
            bucket_region,
            policy,
        ],
    )


def storage_identity_key(platform_id: str, reference: StorageObjectReferenceV1) -> str:
    _validate_exact_nonempty_string(platform_id, "invalid_platform_id")
    return _deterministic_id(
        "storage:v1:",
        [
            INTEGRATION_CONTRACT_VERSION,
            platform_id,
            reference.storage_provider,
            reference.storage_bucket,
            reference.object_key,
            reference.object_version,
        ],
    )


def validate_content_sha256(value: str) -> str:
    if not isinstance(value, str) or not _LOWER_SHA256_RE.fullmatch(value):
        raise StorageIdentityContractError("invalid_content_sha256")
    return value


class ContentFingerprintV1(_FrozenContractModel):
    content_sha256: StrictContractStr
    initial_provenance: ContentFingerprintProvenance

    @field_validator("content_sha256")
    @classmethod
    def _digest(cls, value: str) -> str:
        return validate_content_sha256(value)


def content_fingerprint_from_mode_a(original_bytes: bytes) -> ContentFingerprintV1:
    if not isinstance(original_bytes, bytes):
        raise StorageIdentityContractError("mode_a_original_bytes_required")
    return ContentFingerprintV1(
        content_sha256=hashlib.sha256(original_bytes).hexdigest(),
        initial_provenance=ContentFingerprintProvenance.CORVINTH_COMPUTED,
    )


def content_fingerprint_from_mode_b(content_sha256: str) -> ContentFingerprintV1:
    return ContentFingerprintV1(
        content_sha256=validate_content_sha256(content_sha256),
        initial_provenance=ContentFingerprintProvenance.PLATFORM_ASSERTED,
    )


def validate_content_fingerprint_replay(
    existing: ContentFingerprintV1,
    incoming_content_sha256: str,
) -> ContentFingerprintV1:
    incoming = validate_content_sha256(incoming_content_sha256)
    if incoming != existing.content_sha256:
        raise StorageIdentityContractError("immutable_key_content_conflict")
    return existing


def verify_corvinth_content_fingerprint(
    existing: ContentFingerprintV1,
    original_bytes: bytes,
) -> ContentFingerprintV1:
    computed = content_fingerprint_from_mode_a(original_bytes).content_sha256
    return validate_content_fingerprint_replay(existing, computed)


def resolve_platform_content_id_replay(
    existing_platform_content_id: str | None,
    incoming_platform_content_id: str | None,
) -> str | None:
    if existing_platform_content_id is not None:
        _validate_exact_nonempty_string(
            existing_platform_content_id,
            "invalid_platform_content_id",
        )
    if incoming_platform_content_id is not None:
        _validate_exact_nonempty_string(
            incoming_platform_content_id,
            "invalid_platform_content_id",
        )
    if existing_platform_content_id is None:
        return incoming_platform_content_id
    if (
        incoming_platform_content_id is None
        or incoming_platform_content_id == existing_platform_content_id
    ):
        return existing_platform_content_id
    raise StorageIdentityContractError("platform_content_id_conflict")


def validate_supported_sdk_version(value: str) -> str:
    if not isinstance(value, str) or len(value) > 64:
        raise StorageIdentityContractError("invalid_sdk_version")
    try:
        value.encode("ascii")
    except UnicodeEncodeError as exc:
        raise StorageIdentityContractError("invalid_sdk_version") from exc
    match = _SEMVER_RE.fullmatch(value)
    if match is None:
        raise StorageIdentityContractError("invalid_sdk_version")
    if int(match.group(1)) not in SUPPORTED_SDK_MAJORS:
        raise StorageIdentityContractError("unsupported_sdk_major")
    return value


class DerivedSignalProvenanceV1(_FrozenContractModel):
    integration_contract_version: Literal["storage_identity_v1"] = INTEGRATION_CONTRACT_VERSION
    derivation_source: SignalDerivationSource
    algorithm_version: StrictContractStr
    model_version: StrictContractStr | None = None
    configuration_version: StrictContractStr
    sdk_version: StrictContractStr | None = None

    @field_validator("algorithm_version", "configuration_version")
    @classmethod
    def _required_version(cls, value: str) -> str:
        return _validate_exact_nonempty_string(value, "invalid_signal_version")

    @field_validator("model_version")
    @classmethod
    def _optional_model(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return _validate_exact_nonempty_string(value, "invalid_signal_version")

    @field_validator("sdk_version")
    @classmethod
    def _sdk(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return validate_supported_sdk_version(value)

    @model_validator(mode="after")
    def _client_sdk_required(self) -> "DerivedSignalProvenanceV1":
        if self.derivation_source is SignalDerivationSource.PLATFORM_ASSERTED and self.sdk_version is None:
            raise ValueError("sdk_version_required_for_client_derived_signal")
        return self


def _validate_pdq_hash(value: str) -> str:
    if not isinstance(value, str) or not _HASH64_RE.fullmatch(value):
        raise StorageIdentityContractError("invalid_pdq_hash")
    return value.lower()


def validate_redundant_pdq_fields(
    *,
    pdq_hash: str | None = None,
    pdq_dihedral_hashes: Sequence[str] | None = None,
    pdq_hash_normalized: str | None = None,
    pdq_dihedral_hashes_normalized: Sequence[str] | None = None,
) -> None:
    pairs = (
        (pdq_hash, pdq_dihedral_hashes, "pdq_redundant_standard_mismatch"),
        (
            pdq_hash_normalized,
            pdq_dihedral_hashes_normalized,
            "pdq_redundant_normalized_mismatch",
        ),
    )
    for primary, variants, error_code in pairs:
        if primary is None or variants is None:
            continue
        if not variants:
            raise StorageIdentityContractError(error_code)
        if _validate_pdq_hash(primary) != _validate_pdq_hash(variants[0]):
            raise StorageIdentityContractError(error_code)


def pdq_signal_fingerprint(
    *,
    signal_lane: Literal["standard", "normalized"],
    algorithm_version: str,
    configuration_version: str,
    hashes: Sequence[tuple[str, str]],
) -> str:
    if signal_lane not in {"standard", "normalized"}:
        raise StorageIdentityContractError("invalid_pdq_signal_lane")
    _validate_exact_nonempty_string(algorithm_version, "invalid_signal_version")
    _validate_exact_nonempty_string(configuration_version, "invalid_signal_version")
    if not hashes:
        raise StorageIdentityContractError("pdq_hashes_required")
    canonical_pairs: list[list[str]] = []
    for hash_type, hash_value in hashes:
        if hash_type not in {"standard", "normalized"} or hash_type != signal_lane:
            raise StorageIdentityContractError("pdq_hash_lane_mismatch")
        canonical_pairs.append([hash_type, _validate_pdq_hash(hash_value)])
    canonical_pairs.sort(key=lambda pair: (pair[0], pair[1]))
    return _deterministic_id(
        "signal-fingerprint:v1:",
        [
            "storage-signal-fingerprint:v1",
            "pdq",
            signal_lane,
            algorithm_version,
            None,
            configuration_version,
            canonical_pairs,
        ],
    )


def dino_vector_f32_le_bytes(vector: Sequence[float]) -> bytes:
    if len(vector) != 384:
        raise StorageIdentityContractError("dino_vector_must_have_384_elements")
    encoded = bytearray()
    for value in vector:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise StorageIdentityContractError("invalid_dino_vector_element")
        numeric = float(value)
        if not math.isfinite(numeric):
            raise StorageIdentityContractError("invalid_dino_vector_element")
        try:
            packed = struct.pack("<f", numeric)
        except (OverflowError, struct.error) as exc:
            raise StorageIdentityContractError("invalid_dino_vector_element") from exc
        binary32 = struct.unpack("<f", packed)[0]
        if not math.isfinite(binary32):
            raise StorageIdentityContractError("invalid_dino_vector_element")
        if packed == b"\x00\x00\x00\x80":
            packed = b"\x00\x00\x00\x00"
        encoded.extend(packed)
    result = bytes(encoded)
    if len(result) != 1536:  # pragma: no cover - fixed dimensional invariant.
        raise StorageIdentityContractError("invalid_dino_vector_encoding")
    return result


def dino_vector_f32_le_hex(vector: Sequence[float]) -> str:
    return dino_vector_f32_le_bytes(vector).hex()


def dino_vector_bytes_b64_and_digest(
    vector: Sequence[float],
) -> tuple[str, str]:
    encoded = dino_vector_f32_le_bytes(vector)
    return (
        base64.b64encode(encoded).decode("ascii"),
        hashlib.sha256(encoded).hexdigest(),
    )


def decode_dino_vector_bytes_b64(
    vector_bytes_b64: str,
    vector_digest: str,
) -> tuple[list[float], bytes]:
    if not isinstance(vector_bytes_b64, str) or any(
        character.isspace() for character in vector_bytes_b64
    ):
        raise StorageIdentityContractError("invalid_dino_vector_encoding")
    _validated_lower_sha256(vector_digest, "invalid_dino_vector_digest")
    try:
        encoded = base64.b64decode(vector_bytes_b64, validate=True)
    except (ValueError, TypeError) as exc:
        raise StorageIdentityContractError("invalid_dino_vector_encoding") from exc
    if (
        len(encoded) != 1536
        or base64.b64encode(encoded).decode("ascii") != vector_bytes_b64
        or hashlib.sha256(encoded).hexdigest() != vector_digest
    ):
        raise StorageIdentityContractError("invalid_dino_vector_encoding")
    values = list(struct.unpack("<384f", encoded))
    if any(not math.isfinite(value) for value in values):
        raise StorageIdentityContractError("invalid_dino_vector_encoding")
    if dino_vector_f32_le_bytes(values) != encoded:
        raise StorageIdentityContractError("invalid_dino_vector_encoding")
    return values, encoded


def dino_signal_fingerprint(
    *,
    algorithm_version: str,
    model_version: str,
    configuration_version: str,
    vector: Sequence[float],
) -> str:
    for value in (algorithm_version, model_version, configuration_version):
        _validate_exact_nonempty_string(value, "invalid_signal_version")
    vector_hex = dino_vector_f32_le_hex(vector)
    return _deterministic_id(
        "signal-fingerprint:v1:",
        [
            "storage-signal-fingerprint:v1",
            "dino",
            "embedding",
            algorithm_version,
            model_version,
            configuration_version,
            vector_hex,
        ],
    )


def signal_binding_id(
    *,
    storage_identity_key_value: str,
    signal_family: Literal["pdq", "dino"],
    signal_lane: Literal["standard", "normalized", "embedding"],
    algorithm_version: str,
    model_version: str | None,
    configuration_version: str,
) -> str:
    _validate_exact_nonempty_string(storage_identity_key_value, "invalid_storage_identity_key")
    for value in (algorithm_version, configuration_version):
        _validate_exact_nonempty_string(value, "invalid_signal_version")
    if signal_family == "pdq":
        if signal_lane not in {"standard", "normalized"} or model_version is not None:
            raise StorageIdentityContractError("invalid_pdq_signal_slot")
    elif signal_family == "dino":
        if signal_lane != "embedding" or model_version is None:
            raise StorageIdentityContractError("invalid_dino_signal_slot")
        _validate_exact_nonempty_string(model_version, "invalid_signal_version")
    else:
        raise StorageIdentityContractError("invalid_signal_family")
    return _deterministic_id(
        "storage-signal-binding:v1:",
        [
            "storage_signal_binding_v1",
            storage_identity_key_value,
            signal_family,
            signal_lane,
            algorithm_version,
            model_version,
            configuration_version,
        ],
    )


def validate_signal_slot_replay(
    existing_signal_fingerprint: str,
    incoming_signal_fingerprint: str,
) -> str:
    expected_prefix = "signal-fingerprint:v1:"
    for value in (existing_signal_fingerprint, incoming_signal_fingerprint):
        if not isinstance(value, str) or not value.startswith(expected_prefix):
            raise StorageIdentityContractError("invalid_signal_fingerprint")
        if not _LOWER_SHA256_RE.fullmatch(value.removeprefix(expected_prefix)):
            raise StorageIdentityContractError("invalid_signal_fingerprint")
    if existing_signal_fingerprint != incoming_signal_fingerprint:
        raise StorageIdentityContractError("immutable_key_signal_conflict")
    return existing_signal_fingerprint


class ConfirmedHashReferenceV1(_FrozenContractModel):
    type: Literal["confirmed_hash"] = "confirmed_hash"
    confirmation_key: StrictContractStr
    matched_lane: Literal["standard", "normalized"]

    @field_validator("confirmation_key")
    @classmethod
    def _key(cls, value: str) -> str:
        return _validate_exact_nonempty_string(value, "invalid_confirmation_key")


class ComplaintReferenceV1(_FrozenContractModel):
    type: Literal["complaint"] = "complaint"
    complaint_id: StrictContractStr
    matched_case_id: StrictContractStr | None = None

    @field_validator("complaint_id")
    @classmethod
    def _complaint(cls, value: str) -> str:
        return _validate_exact_nonempty_string(value, "invalid_complaint_id")

    @field_validator("matched_case_id")
    @classmethod
    def _case(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return _validate_exact_nonempty_string(value, "invalid_matched_case_id")


MatchedReferenceV1: TypeAlias = Annotated[
    ConfirmedHashReferenceV1 | ComplaintReferenceV1 | StorageObjectReferenceV1,
    Field(discriminator="type"),
]
MATCHED_REFERENCE_V1_ADAPTER = TypeAdapter(MatchedReferenceV1)


class MatchReferencesV1(_FrozenContractModel):
    action_reference: StorageObjectReferenceV1 | None = None
    matched_reference: MatchedReferenceV1 | None = None


def matched_reference_digest_projection(
    reference: MatchedReferenceV1 | None,
) -> list[Any] | None:
    if reference is None:
        return None
    if isinstance(reference, ConfirmedHashReferenceV1):
        return ["confirmed_hash", reference.confirmation_key, reference.matched_lane]
    if isinstance(reference, ComplaintReferenceV1):
        return ["complaint", reference.complaint_id, reference.matched_case_id]
    if isinstance(reference, StorageObjectReferenceV1):
        return [
            "storage_object",
            reference.storage_provider,
            reference.storage_bucket,
            reference.object_key,
            reference.object_version,
        ]
    raise StorageIdentityContractError("invalid_matched_reference")


def case_action_authority_id(
    *,
    platform_id: str,
    case_uuid: str,
    storage_identity_key_value: str,
    requested_action: str = STORAGE_ACTION_REQUESTED_ACTION,
) -> str:
    for value, code in (
        (platform_id, "invalid_platform_id"),
        (case_uuid, "invalid_case_uuid"),
        (storage_identity_key_value, "invalid_storage_identity_key"),
    ):
        _validate_exact_nonempty_string(value, code)
    if requested_action != STORAGE_ACTION_REQUESTED_ACTION:
        raise StorageIdentityContractError("invalid_storage_requested_action")
    return _deterministic_id(
        "case-action:v1:",
        [
            "storage-case-action:v1",
            platform_id,
            case_uuid,
            storage_identity_key_value,
            requested_action,
        ],
    )


def format_utc_rfc3339_microseconds(value: datetime) -> str:
    if not isinstance(value, datetime):
        raise StorageIdentityContractError("invalid_occurred_at")
    if value.tzinfo is None or value.utcoffset() is None:
        raise StorageIdentityContractError("invalid_occurred_at")
    return value.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def authorize_same_tenant_storage_reference(
    *,
    authenticated_platform_id: str,
    referenced_platform_id: str,
    reference: StorageObjectReferenceV1,
) -> StorageObjectReferenceV1:
    if authenticated_platform_id != referenced_platform_id:
        raise StorageIdentityContractError("cross_tenant_storage_reference_forbidden")
    return reference


def backfill_item_id(
    *,
    platform_id: str,
    corpus_kind: CorpusKind | str,
    corpus_id: str,
    scan_context_id: str | None,
    storage_identity_key_value: str,
) -> str:
    try:
        kind = CorpusKind(corpus_kind)
    except ValueError as exc:
        raise StorageIdentityContractError("invalid_corpus_kind") from exc
    for value, code in (
        (platform_id, "invalid_platform_id"),
        (corpus_id, "invalid_corpus_id"),
        (storage_identity_key_value, "invalid_storage_identity_key"),
    ):
        _validate_exact_nonempty_string(value, code)
    if kind is CorpusKind.PULSE_LIBRARY and scan_context_id is not None:
        raise StorageIdentityContractError("pulse_library_scan_context_must_be_null")
    if kind is CorpusKind.COMPLAINT_SCAN:
        _validate_exact_nonempty_string(scan_context_id, "complaint_scan_context_required")
    if kind is CorpusKind.SHIELD_ARCHIVE:
        if scan_context_id is not None:
            raise StorageIdentityContractError("shield_archive_scan_context_must_be_null")
        if re.fullmatch(r"shield_archive:shield-run:v1:[0-9a-f]{64}", corpus_id) is None:
            raise StorageIdentityContractError("invalid_shield_corpus_id")
    return _deterministic_id(
        "backfill-item:v1:",
        [
            INTEGRATION_CONTRACT_VERSION,
            platform_id,
            kind.value,
            corpus_id,
            scan_context_id,
            storage_identity_key_value,
        ],
    )


def backfill_execution_id(
    *,
    platform_id: str,
    job_id: str,
    item_id: str,
    attempt_generation: int,
) -> str:
    for value, code in (
        (platform_id, "invalid_platform_id"),
        (job_id, "invalid_job_id"),
        (item_id, "invalid_item_id"),
    ):
        _validate_exact_nonempty_string(value, code)
    if isinstance(attempt_generation, bool) or not isinstance(attempt_generation, int) or attempt_generation < 0:
        raise StorageIdentityContractError("invalid_attempt_generation")
    return _deterministic_id(
        "backfill-execution:v1:",
        [platform_id, job_id, item_id, attempt_generation],
    )


def validate_backfill_client_id(value: str) -> str:
    if not isinstance(value, str) or _BACKFILL_CLIENT_ID_RE.fullmatch(value) is None:
        raise StorageIdentityContractError("invalid_backfill_client_id")
    return value


def backfill_job_id(*, platform_id: str, client_job_id: str) -> str:
    _validate_exact_nonempty_string(platform_id, "invalid_platform_id")
    validate_backfill_client_id(client_job_id)
    return _deterministic_id(
        "backfill-job:v1:",
        ["storage-backfill-job:v1", platform_id, client_job_id],
    )


def complaint_scan_context_id(
    *,
    platform_id: str,
    complaint_id: str,
    complaint_case_id: str,
    comparison_signal_fingerprint: str,
    algorithm_version: str,
    model_version: str,
    configuration_version: str,
) -> str:
    for value, code in (
        (platform_id, "invalid_platform_id"),
        (complaint_id, "invalid_complaint_id"),
        (complaint_case_id, "invalid_case_id"),
        (comparison_signal_fingerprint, "invalid_signal_fingerprint"),
        (algorithm_version, "invalid_signal_version"),
        (model_version, "invalid_signal_version"),
        (configuration_version, "invalid_signal_version"),
    ):
        _validate_exact_nonempty_string(value, code)
    return _deterministic_id(
        "complaint-scan:v1:",
        [
            "storage-complaint-scan:v1",
            platform_id,
            complaint_id,
            complaint_case_id,
            comparison_signal_fingerprint,
            algorithm_version,
            model_version,
            configuration_version,
        ],
    )


def complaint_corpus_id(complaint_case_id: str) -> str:
    _validate_exact_nonempty_string(complaint_case_id, "invalid_case_id")
    return "complaint:" + complaint_case_id


def backfill_job_intent_digest(
    *,
    platform_id: str,
    client_job_id: str,
    corpus_kind: CorpusKind | str,
    corpus_id: str,
    scan_context_id: str | None,
    complaint_id: str | None,
    complaint_case_id: str | None,
    expected_item_count: int,
    storage_integration_id: str,
    storage_provider: str,
    storage_bucket: str,
    bucket_region: str,
    version_policy: VersionPolicy | str,
    storage_configuration_version: int,
    storage_configuration_digest: str,
    integration_contract_version: str,
    algorithm_version: str,
    model_version: str,
    configuration_version: str,
    comparison_signal_fingerprint: str | None,
) -> str:
    kind = CorpusKind(corpus_kind)
    if kind is CorpusKind.SHIELD_ARCHIVE:
        raise StorageIdentityContractError("shield_archive_requires_shield_job_intent")
    policy = VersionPolicy(version_policy)
    validate_backfill_client_id(client_job_id)
    if (
        isinstance(expected_item_count, bool)
        or not isinstance(expected_item_count, int)
        or not 1 <= expected_item_count <= BACKFILL_JOB_MAX_ITEMS[kind.value]
    ):
        raise StorageIdentityContractError("invalid_expected_item_count")
    if kind is CorpusKind.PULSE_LIBRARY:
        if any(value is not None for value in (
            scan_context_id, complaint_id, complaint_case_id,
            comparison_signal_fingerprint,
        )):
            raise StorageIdentityContractError("pulse_library_complaint_scope_forbidden")
        expected_corpus_id = PULSE_LIBRARY_CORPUS_ID
    else:
        for value in (
            scan_context_id, complaint_id, complaint_case_id,
            comparison_signal_fingerprint,
        ):
            _validate_exact_nonempty_string(value, "complaint_scan_authority_required")
        expected_corpus_id = complaint_corpus_id(complaint_case_id)
    if corpus_id != expected_corpus_id:
        raise StorageIdentityContractError("invalid_corpus_id")
    values = (
        platform_id, storage_integration_id, storage_provider, storage_bucket,
        bucket_region, storage_configuration_digest, integration_contract_version,
        algorithm_version, model_version, configuration_version,
    )
    if any(not isinstance(value, str) or not value for value in values):
        raise StorageIdentityContractError("invalid_backfill_job_intent")
    if storage_provider != StorageProvider.S3.value:
        raise StorageIdentityContractError("unsupported_storage_provider")
    if integration_contract_version != INTEGRATION_CONTRACT_VERSION:
        raise StorageIdentityContractError("invalid_integration_contract_version")
    if (
        isinstance(storage_configuration_version, bool)
        or not isinstance(storage_configuration_version, int)
        or storage_configuration_version < 1
    ):
        raise StorageIdentityContractError("invalid_storage_configuration_version")
    return hashlib.sha256(canonical_json_array_v1([
        "storage-backfill-job-intent:v1",
        platform_id,
        client_job_id,
        kind.value,
        corpus_id,
        scan_context_id,
        complaint_id,
        complaint_case_id,
        expected_item_count,
        storage_integration_id,
        storage_provider,
        storage_bucket,
        bucket_region,
        policy.value,
        storage_configuration_version,
        storage_configuration_digest,
        integration_contract_version,
        algorithm_version,
        model_version,
        configuration_version,
        comparison_signal_fingerprint,
    ])).hexdigest()


def registration_request_digest(
    *,
    platform_id: str,
    job_id: str,
    registration_request_id: str,
    expected_coordination_revision: int,
    entries: Sequence[tuple[str, str | None]],
) -> str:
    validate_backfill_client_id(registration_request_id)
    if (
        isinstance(expected_coordination_revision, bool)
        or not isinstance(expected_coordination_revision, int)
        or expected_coordination_revision < 0
    ):
        raise StorageIdentityContractError("invalid_coordination_revision")
    ordered: list[list[str | None]] = []
    seen: set[str] = set()
    for storage_key, platform_content_id in entries:
        _validate_exact_nonempty_string(storage_key, "invalid_storage_identity_key")
        if storage_key in seen:
            raise StorageIdentityContractError("duplicate_registration_storage_identity")
        seen.add(storage_key)
        if platform_content_id is not None:
            _validate_exact_nonempty_string(platform_content_id, "invalid_platform_content_id")
        ordered.append([storage_key, platform_content_id])
    if not 1 <= len(ordered) <= BACKFILL_REGISTRATION_PAGE_MAX_ITEMS:
        raise StorageIdentityContractError("invalid_registration_page_size")
    ordered.sort(key=lambda entry: entry[0].encode("utf-8"))
    return hashlib.sha256(canonical_json_array_v1([
        "storage-backfill-registration-request:v1",
        platform_id,
        job_id,
        registration_request_id,
        expected_coordination_revision,
        ordered,
    ])).hexdigest()


def canonical_f64_hex(value: float) -> str:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise StorageIdentityContractError("invalid_finite_float")
    converted = float(value)
    if not math.isfinite(converted):
        raise StorageIdentityContractError("invalid_finite_float")
    if converted == 0.0:
        converted = 0.0
    return struct.pack(">d", converted).hex()


def complaint_item_result_digest(
    *,
    job_id: str,
    item_id: str,
    scan_context_id: str,
    storage_identity_key_value: str,
    result_generation: int,
    cosine_similarity: float,
    decision: Literal["match", "no_match", "calibration_pending"],
    threshold_value: float | None,
    threshold_contract_version: str,
    algorithm_version: str,
    model_version: str,
    configuration_version: str,
) -> str:
    if decision not in {"match", "no_match", "calibration_pending"}:
        raise StorageIdentityContractError("invalid_complaint_decision")
    if isinstance(result_generation, bool) or not isinstance(result_generation, int) or result_generation < 0:
        raise StorageIdentityContractError("invalid_result_generation")
    score_hex = canonical_f64_hex(cosine_similarity)
    threshold_hex = None if threshold_value is None else canonical_f64_hex(threshold_value)
    return _deterministic_id(
        "complaint-item-result:v1:",
        [
            "complaint-item-result:v1", job_id, item_id, scan_context_id,
            storage_identity_key_value, result_generation, score_hex, decision,
            threshold_hex, threshold_contract_version, algorithm_version,
            model_version, configuration_version,
        ],
    )


def pulse_library_backfill_result_digest(
    *,
    platform_id: str,
    job_id: str,
    item_id: str,
    result_generation: int,
    storage_identity_key_value: str,
    content_sha256: str,
    signal_binding_id_value: str,
    signal_fingerprint: str,
    vector_digest: str,
) -> str:
    return _deterministic_id(
        "backfill-result:v1:",
        [
            "storage-backfill-result:v1", platform_id, job_id, item_id,
            result_generation, PULSE_LIBRARY_CORPUS_KIND,
            PULSE_LIBRARY_CORPUS_ID, None, storage_identity_key_value,
            validate_content_sha256(content_sha256), signal_binding_id_value,
            signal_fingerprint,
            _validated_lower_sha256(vector_digest, "invalid_dino_vector_digest"),
            None, None, None,
        ],
    )


def pulse_threshold_contract_version(
    *,
    algorithm_version: str,
    model_version: str,
    configuration_version: str,
    match_threshold_q1e6: int,
    calibration_method_version: str,
    calibration_manifest_digest: str,
) -> str:
    if (
        isinstance(match_threshold_q1e6, bool)
        or not isinstance(match_threshold_q1e6, int)
        or not -1_000_000 <= match_threshold_q1e6 <= 1_000_000
    ):
        raise StorageIdentityContractError("invalid_match_threshold")
    return _deterministic_id(
        "pulse-thresholds:v1:",
        [
            "pulse-thresholds:v1", algorithm_version, model_version,
            configuration_version, "cosine", match_threshold_q1e6,
            calibration_method_version, calibration_manifest_digest,
        ],
    )


def complaint_scan_completion_digest(
    *,
    job_id: str,
    scan_context_id: str,
    corpus_id: str,
    manifest_digest: str,
    completed_count: int,
    failed_count: int,
    cancelled_count: int,
    match_count: int,
    no_match_count: int,
    calibration_pending_count: int,
    terminal_entries: Sequence[Sequence[Any]],
    surfaced_matches: Sequence[Sequence[Any]],
) -> str:
    counts = (
        completed_count, failed_count, cancelled_count, match_count,
        no_match_count, calibration_pending_count,
    )
    if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in counts):
        raise StorageIdentityContractError("invalid_complaint_completion_counts")
    ordered_terminal = sorted(
        [list(entry) for entry in terminal_entries],
        key=lambda entry: entry[0].encode("utf-8"),
    )
    ordered_matches = [list(entry) for entry in surfaced_matches]
    if len(ordered_matches) > 50:
        raise StorageIdentityContractError("too_many_surfaced_matches")
    return _deterministic_id(
        "complaint-scan-completion:v1:",
        [
            "complaint-scan-completion:v1", job_id, scan_context_id,
            corpus_id, manifest_digest,
            list(counts), ordered_terminal, ordered_matches,
        ],
    )


def complaint_scan_completion_webhook_body_v1(
    *,
    event_id: str,
    platform_id: str,
    job_id: str,
    client_job_id: str,
    complaint_id: str,
    complaint_case_id: str,
    scan_context_id: str,
    corpus_id: str,
    job_status: Literal["completed", "completed_with_failures", "cancelled"],
    occurred_at: str,
    aggregate_completion_digest: str,
    completed_count: int,
    failed_count: int,
    cancelled_count: int,
    match_count: int,
    no_match_count: int,
    calibration_pending_count: int,
    matches: Sequence[Mapping[str, Any]],
    threshold_contract_version: str,
) -> dict[str, Any]:
    try:
        parsed_event_id = uuid.UUID(event_id)
    except (AttributeError, TypeError, ValueError) as exc:
        raise StorageIdentityContractError("invalid_webhook_event_id") from exc
    if str(parsed_event_id) != event_id:
        raise StorageIdentityContractError("invalid_webhook_event_id")
    return {
        "event": "pulse_burst_scan_complete",
        "event_id": event_id,
        "event_type": "complaint.scan.completed",
        "webhook_contract_version": "complaint_scan_completed:v1",
        "integration_contract_version": INTEGRATION_CONTRACT_VERSION,
        "occurred_at": occurred_at,
        "platform_id": platform_id,
        "job_id": job_id,
        "client_job_id": client_job_id,
        "complaint_id": complaint_id,
        "complaint_case_id": complaint_case_id,
        "case_uuid": complaint_case_id,
        "scan_context_id": scan_context_id,
        "corpus_kind": "complaint_scan",
        "corpus_id": corpus_id,
        "job_status": job_status,
        "aggregate_completion_digest": aggregate_completion_digest,
        "completed_count": completed_count,
        "failed_count": failed_count,
        "cancelled_count": cancelled_count,
        "match_count": match_count,
        "no_match_count": no_match_count,
        "calibration_pending_count": calibration_pending_count,
        "matches": [dict(match) for match in matches],
        "threshold_contract_version": threshold_contract_version,
    }


def qdrant_library_point_id(
    *,
    platform_id: str,
    corpus_id: str,
    storage_identity_key_value: str,
    algorithm_version: str,
    model_version: str,
    configuration_version: str,
) -> str:
    values = (
        (platform_id, "invalid_platform_id"),
        (corpus_id, "invalid_corpus_id"),
        (storage_identity_key_value, "invalid_storage_identity_key"),
        (algorithm_version, "invalid_signal_version"),
        (model_version, "invalid_signal_version"),
        (configuration_version, "invalid_signal_version"),
    )
    for value, code in values:
        _validate_exact_nonempty_string(value, code)
    logical_id = _deterministic_id(
        "qdrant-point:v2:",
        [
            "storage-library-point:v2",
            platform_id,
            corpus_id,
            storage_identity_key_value,
            "dino",
            algorithm_version,
            model_version,
            configuration_version,
        ],
    )
    # Only the approved AWS generation uses a Qdrant-compatible physical UUID.
    # Historical IDs and all Mongo/raw signal identities remain unchanged.
    if (algorithm_version, model_version, configuration_version) == (
        "corvinth-dinov2-cls-embedding-v1",
        "facebook/dinov2-small@ed25f3a31f01632728cabb09d1542f84ab7b0056:"
        "aws-artifact-sha256:61c5be4f613f078a1df6d6d70f98d60523f696ec27fe65279f296558048c2e6f",
        "corvinth-dinov2-preprocess-384-v1",
    ):
        return str(uuid.uuid5(
            uuid.NAMESPACE_URL,
            "urn:corvinth:qdrant:aws-dino-point:v1:" + logical_id,
        ))
    return logical_id


def qdrant_library_payload_v2(
    *,
    platform_id: str,
    storage_identity_key_value: str,
    signal_binding_id_value: str,
    algorithm_version: str,
    model_version: str,
    configuration_version: str,
    signal_fingerprint: str,
) -> dict[str, str]:
    for value, code in (
        (platform_id, "invalid_platform_id"),
        (storage_identity_key_value, "invalid_storage_identity_key"),
        (signal_binding_id_value, "invalid_signal_binding_id"),
        (algorithm_version, "invalid_signal_version"),
        (model_version, "invalid_signal_version"),
        (configuration_version, "invalid_signal_version"),
        (signal_fingerprint, "invalid_signal_fingerprint"),
    ):
        _validate_exact_nonempty_string(value, code)
    return {
        "platform_id": platform_id,
        "corpus_kind": PULSE_LIBRARY_CORPUS_KIND,
        "corpus_id": PULSE_LIBRARY_CORPUS_ID,
        "storage_identity_key": storage_identity_key_value,
        "signal_binding_id": signal_binding_id_value,
        "algorithm_version": algorithm_version,
        "model_version": model_version,
        "configuration_version": configuration_version,
        "signal_fingerprint": signal_fingerprint,
    }


def qdrant_signal_result_digest(
    *,
    signal_binding_id_value: str,
    signal_fingerprint: str,
    vector_digest: str,
) -> str:
    for value, code in (
        (signal_binding_id_value, "invalid_signal_binding_id"),
        (signal_fingerprint, "invalid_signal_fingerprint"),
    ):
        _validate_exact_nonempty_string(value, code)
    _validated_lower_sha256(vector_digest, "invalid_dino_vector_digest")
    return hashlib.sha256(
        canonical_json_array_v1([
            "storage-result",
            "synchronous_signal_binding",
            signal_binding_id_value,
            signal_fingerprint,
            vector_digest,
        ])
    ).hexdigest()


def qdrant_upsert_intent_digest(
    *,
    destination_generation: str,
    point_id: str,
    signal_binding_id_value: str,
    signal_fingerprint: str,
    vector_digest: str,
    payload: Mapping[str, Any],
) -> str:
    expected_payload_keys = set(QDRANT_PAYLOAD_FIELDS)
    if set(payload) != expected_payload_keys:
        raise StorageIdentityContractError("invalid_qdrant_payload")
    return hashlib.sha256(
        canonical_json_array_v1([
            "storage_qdrant_upsert_intent_v1",
            destination_generation,
            point_id,
            QDRANT_VECTOR_NAME,
            signal_binding_id_value,
            signal_fingerprint,
            _validated_lower_sha256(
                vector_digest,
                "invalid_dino_vector_digest",
            ),
            payload["platform_id"],
            payload["corpus_kind"],
            payload["corpus_id"],
            payload["storage_identity_key"],
            payload["algorithm_version"],
            payload["model_version"],
            payload["configuration_version"],
        ])
    ).hexdigest()


def qdrant_upsert_intent_v1(
    *,
    destination_generation: str,
    platform_id: str,
    storage_identity_key_value: str,
    algorithm_version: str,
    model_version: str,
    configuration_version: str,
    vector: Sequence[float],
) -> tuple[dict[str, Any], str, str]:
    signal_fingerprint = dino_signal_fingerprint(
        algorithm_version=algorithm_version,
        model_version=model_version,
        configuration_version=configuration_version,
        vector=vector,
    )
    binding_id = signal_binding_id(
        storage_identity_key_value=storage_identity_key_value,
        signal_family="dino",
        signal_lane="embedding",
        algorithm_version=algorithm_version,
        model_version=model_version,
        configuration_version=configuration_version,
    )
    point_id = qdrant_library_point_id(
        platform_id=platform_id,
        corpus_id=PULSE_LIBRARY_CORPUS_ID,
        storage_identity_key_value=storage_identity_key_value,
        algorithm_version=algorithm_version,
        model_version=model_version,
        configuration_version=configuration_version,
    )
    vector_bytes_b64, vector_digest = dino_vector_bytes_b64_and_digest(vector)
    payload = qdrant_library_payload_v2(
        platform_id=platform_id,
        storage_identity_key_value=storage_identity_key_value,
        signal_binding_id_value=binding_id,
        algorithm_version=algorithm_version,
        model_version=model_version,
        configuration_version=configuration_version,
        signal_fingerprint=signal_fingerprint,
    )
    intent = {
        "point_id": point_id,
        "vector_name": QDRANT_VECTOR_NAME,
        "signal_binding_id": binding_id,
        "signal_fingerprint": signal_fingerprint,
        "vector_bytes_b64": vector_bytes_b64,
        "vector_digest": vector_digest,
        "payload": payload,
    }
    result_digest = qdrant_signal_result_digest(
        signal_binding_id_value=binding_id,
        signal_fingerprint=signal_fingerprint,
        vector_digest=vector_digest,
    )
    intent_digest = qdrant_upsert_intent_digest(
        destination_generation=destination_generation,
        point_id=point_id,
        signal_binding_id_value=binding_id,
        signal_fingerprint=signal_fingerprint,
        vector_digest=vector_digest,
        payload=payload,
    )
    return intent, result_digest, intent_digest


class ManifestItemV1(_FrozenContractModel):
    item_id: StrictContractStr
    storage_identity_key: StrictContractStr
    storage_reference: StorageObjectReferenceV1
    platform_content_id: StrictContractStr | None = None

    @field_validator("item_id", "storage_identity_key")
    @classmethod
    def _required_id(cls, value: str) -> str:
        return _validate_exact_nonempty_string(value, "invalid_manifest_item")

    @field_validator("platform_content_id")
    @classmethod
    def _optional_correlation(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return _validate_exact_nonempty_string(value, "invalid_platform_content_id")

    def projection(self) -> list[Any]:
        return [
            "storage-manifest-item:v1",
            self.item_id,
            self.storage_identity_key,
            self.storage_reference.storage_provider,
            self.storage_reference.storage_bucket,
            self.storage_reference.object_key,
            self.storage_reference.object_version,
            self.platform_content_id,
        ]


class ManifestHeaderV1(_FrozenContractModel):
    platform_id: StrictContractStr
    client_job_id: StrictContractStr
    corpus_kind: CorpusKind
    corpus_id: StrictContractStr
    scan_context_id: StrictContractStr | None
    expected_item_count: NonNegativeContractInt
    algorithm_version: StrictContractStr
    model_version: StrictContractStr
    configuration_version: StrictContractStr
    integration_configuration_digest: StrictContractStr
    integration_contract_version: Literal["storage_identity_v1"] = INTEGRATION_CONTRACT_VERSION

    @field_validator(
        "platform_id",
        "client_job_id",
        "corpus_id",
        "algorithm_version",
        "model_version",
        "configuration_version",
        "integration_configuration_digest",
    )
    @classmethod
    def _required(cls, value: str) -> str:
        return _validate_exact_nonempty_string(value, "invalid_manifest_header")

    @field_validator("scan_context_id")
    @classmethod
    def _optional_scan(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return _validate_exact_nonempty_string(value, "invalid_scan_context_id")

    @model_validator(mode="after")
    def _scan_context_contract(self) -> "ManifestHeaderV1":
        if self.corpus_kind is CorpusKind.SHIELD_ARCHIVE:
            raise ValueError("shield_archive_requires_shield_manifest_header")
        if self.corpus_kind is CorpusKind.PULSE_LIBRARY and self.scan_context_id is not None:
            raise ValueError("pulse_library_scan_context_must_be_null")
        if self.corpus_kind is CorpusKind.COMPLAINT_SCAN and self.scan_context_id is None:
            raise ValueError("complaint_scan_context_required")
        return self


def _sorted_manifest_projections(items: Sequence[ManifestItemV1]) -> list[list[Any]]:
    seen_item_ids: set[str] = set()
    seen_storage_keys: set[str] = set()
    ordered: list[ManifestItemV1] = []
    for item in items:
        if item.item_id in seen_item_ids:
            raise StorageIdentityContractError("duplicate_manifest_item_id")
        if item.storage_identity_key in seen_storage_keys:
            raise StorageIdentityContractError("duplicate_manifest_storage_identity")
        seen_item_ids.add(item.item_id)
        seen_storage_keys.add(item.storage_identity_key)
        ordered.append(item)
    ordered.sort(key=lambda item: item.item_id.encode("utf-8"))
    return [item.projection() for item in ordered]


def storage_manifest_digest(
    header: ManifestHeaderV1,
    items: Sequence[ManifestItemV1],
) -> str:
    projections = _sorted_manifest_projections(items)
    if header.expected_item_count != len(projections):
        raise StorageIdentityContractError("manifest_item_count_mismatch")
    return _deterministic_id(
        "manifest:v1:",
        [
            "storage-manifest:v1",
            header.platform_id,
            header.client_job_id,
            header.corpus_kind.value,
            header.corpus_id,
            header.scan_context_id,
            header.expected_item_count,
            header.algorithm_version,
            header.model_version,
            header.configuration_version,
            header.integration_configuration_digest,
            header.integration_contract_version,
            projections,
        ],
    )


def registration_page_digest(items: Sequence[ManifestItemV1]) -> str:
    return _deterministic_id(
        "registration-page-payload:v1:",
        ["storage-registration-page-payload:v1", _sorted_manifest_projections(items)],
    )


def registration_page_id(job_id: str, page_digest: str) -> str:
    _validate_exact_nonempty_string(job_id, "invalid_job_id")
    _validate_exact_nonempty_string(page_digest, "invalid_registration_page_digest")
    return _deterministic_id(
        "registration-page:v1:",
        ["storage-registration-page:v1", job_id, page_digest],
    )


_OUTBOX_KIND_MATRIX = {
    (
        OutboxProducerKind.SYNCHRONOUS_SIGNAL_BINDING,
        OutboxEffectKind.QDRANT_LIBRARY_UPSERT,
    ): OutboxAuthorityKind.SIGNAL_BINDING,
    (
        OutboxProducerKind.BACKFILL_ITEM,
        OutboxEffectKind.QDRANT_LIBRARY_UPSERT,
    ): OutboxAuthorityKind.BACKFILL_ITEM,
    (
        OutboxProducerKind.COMPLAINT_SCAN_COMPLETION,
        OutboxEffectKind.COMPLAINT_SCAN_COMPLETE_WEBHOOK,
    ): OutboxAuthorityKind.COMPLAINT_SCAN_COMPLETION,
    (
        OutboxProducerKind.CASE_ACTION,
        OutboxEffectKind.STORAGE_ACTION_WEBHOOK,
    ): OutboxAuthorityKind.CASE_ACTION,
}


class TypedOutboxIdentityV1(_FrozenContractModel):
    producer_kind: OutboxProducerKind
    effect_kind: OutboxEffectKind
    authority_kind: OutboxAuthorityKind
    authority_id: StrictContractStr
    authority_generation: NonNegativeContractInt | None
    result_digest: StrictContractStr

    @field_validator("authority_id")
    @classmethod
    def _required(cls, value: str) -> str:
        return _validate_exact_nonempty_string(value, "invalid_outbox_identity")

    @field_validator("result_digest")
    @classmethod
    def _digest(cls, value: str) -> str:
        return _validated_lower_sha256(value, "invalid_outbox_result_digest")

    @field_validator("authority_generation")
    @classmethod
    def _generation(cls, value: int | None) -> int | None:
        if value is not None and (isinstance(value, bool) or value < 0):
            raise ValueError("invalid_authority_generation")
        return value

    @model_validator(mode="after")
    def _typed_pair(self) -> "TypedOutboxIdentityV1":
        expected = _OUTBOX_KIND_MATRIX.get((self.producer_kind, self.effect_kind))
        if expected is None or self.authority_kind is not expected:
            raise ValueError("invalid_outbox_producer_effect_authority")
        if self.producer_kind in {
            OutboxProducerKind.SYNCHRONOUS_SIGNAL_BINDING,
            OutboxProducerKind.COMPLAINT_SCAN_COMPLETION,
        } and self.authority_generation is not None:
            raise ValueError("outbox_generation_must_be_null")
        if (
            self.producer_kind is OutboxProducerKind.BACKFILL_ITEM
            and self.authority_generation is None
        ):
            raise ValueError("backfill_outbox_generation_required")
        return self

    @property
    def outbox_id(self) -> str:
        return _deterministic_id(
            "result-outbox:v1:",
            [
                "storage-result-outbox:v1",
                self.producer_kind.value,
                self.effect_kind.value,
                self.authority_kind.value,
                self.authority_id,
                self.authority_generation,
                self.result_digest,
            ],
        )


def backfill_result_authority_id(job_id: str, item_id: str) -> str:
    _validate_exact_nonempty_string(job_id, "invalid_job_id")
    _validate_exact_nonempty_string(item_id, "invalid_item_id")
    return _deterministic_id(
        "backfill-result-authority:v1:",
        ["backfill-result-authority:v1", job_id, item_id],
    )


def complaint_scan_webhook_action_id(job_id: str, aggregate_completion_digest: str) -> str:
    _validate_exact_nonempty_string(job_id, "invalid_job_id")
    _validate_exact_nonempty_string(
        aggregate_completion_digest,
        "invalid_aggregate_completion_digest",
    )
    return _deterministic_id(
        "complaint-scan-webhook-action:v1:",
        ["complaint-scan-webhook-action:v1", job_id, aggregate_completion_digest],
    )


def webhook_event_id(
    *,
    event_type: str,
    platform_id: str,
    case_uuid: str,
    immutable_logical_action_kind: str,
    immutable_logical_action_id: str,
) -> str:
    for value, code in (
        (event_type, "invalid_webhook_event_type"),
        (platform_id, "invalid_platform_id"),
        (case_uuid, "invalid_case_uuid"),
        (immutable_logical_action_kind, "invalid_logical_action_kind"),
        (immutable_logical_action_id, "invalid_logical_action_id"),
    ):
        _validate_exact_nonempty_string(value, code)
    return _deterministic_id(
        "webhook-event:v1:",
        [
            "corvinth-webhook:v1",
            event_type,
            platform_id,
            case_uuid,
            immutable_logical_action_kind,
            immutable_logical_action_id,
        ],
    )


def _matched_reference_webhook_document(
    reference: MatchedReferenceV1 | None,
) -> dict[str, Any] | None:
    if reference is None:
        return None
    if isinstance(reference, ConfirmedHashReferenceV1):
        return {
            "type": "confirmed_hash",
            "confirmation_key": reference.confirmation_key,
            "matched_lane": reference.matched_lane,
        }
    if isinstance(reference, ComplaintReferenceV1):
        return {
            "type": "complaint",
            "complaint_id": reference.complaint_id,
            "matched_case_id": reference.matched_case_id,
        }
    if isinstance(reference, StorageObjectReferenceV1):
        return {
            "type": "storage_object",
            "storage_provider": reference.storage_provider,
            "storage_bucket": reference.storage_bucket,
            "object_key": reference.object_key,
            "object_version": reference.object_version,
        }
    raise StorageIdentityContractError("invalid_matched_reference")


def storage_action_result_digest(
    *,
    case_action_authority_id: str,
    platform_id: str,
    case_uuid: str,
    storage_identity_key_value: str,
    occurred_at: str,
    classification: str | None,
    hamming_distance: int | None,
    matched_reference: MatchedReferenceV1 | None,
    matched_case_id: str | None,
    client_reference_id: str | None,
    requested_action: str = STORAGE_ACTION_REQUESTED_ACTION,
) -> str:
    for value, code in (
        (case_action_authority_id, "invalid_case_action_authority"),
        (platform_id, "invalid_platform_id"),
        (case_uuid, "invalid_case_uuid"),
        (storage_identity_key_value, "invalid_storage_identity_key"),
        (occurred_at, "invalid_occurred_at"),
    ):
        _validate_exact_nonempty_string(value, code)
    if requested_action != STORAGE_ACTION_REQUESTED_ACTION:
        raise StorageIdentityContractError("invalid_storage_requested_action")
    if hamming_distance is not None and (
        isinstance(hamming_distance, bool) or not isinstance(hamming_distance, int)
    ):
        raise StorageIdentityContractError("invalid_hamming_distance")
    return hashlib.sha256(
        canonical_json_array_v1([
            "storage-result",
            "case_action",
            case_action_authority_id,
            platform_id,
            case_uuid,
            storage_identity_key_value,
            requested_action,
            occurred_at,
            classification,
            hamming_distance,
            matched_reference_digest_projection(matched_reference),
            matched_case_id,
            client_reference_id,
        ])
    ).hexdigest()


def storage_action_webhook_body_v1(
    *,
    platform_id: str,
    case_uuid: str,
    case_action_authority_id: str,
    occurred_at: str,
    action_reference: StorageObjectReferenceV1,
    classification: str | None,
    hamming_distance: int | None,
    matched_reference: MatchedReferenceV1 | None,
    matched_case_id: str | None,
    client_reference_id: str | None,
) -> dict[str, Any]:
    event_id = webhook_event_id(
        event_type=STORAGE_ACTION_EVENT_TYPE,
        platform_id=platform_id,
        case_uuid=case_uuid,
        immutable_logical_action_kind="storage_action",
        immutable_logical_action_id=case_action_authority_id,
    )
    return {
        "event": "content_match",
        "event_id": event_id,
        "event_type": STORAGE_ACTION_EVENT_TYPE,
        "webhook_contract_version": STORAGE_ACTION_WEBHOOK_CONTRACT_VERSION,
        "integration_contract_version": INTEGRATION_CONTRACT_VERSION,
        "occurred_at": occurred_at,
        "platform_id": platform_id,
        "case_uuid": case_uuid,
        "logical_action_id": case_action_authority_id,
        "requested_action": STORAGE_ACTION_REQUESTED_ACTION,
        "action_required": STORAGE_ACTION_REQUESTED_ACTION,
        "classification": classification,
        "hamming_distance": hamming_distance,
        "matched_case_id": matched_case_id,
        "client_reference_id": client_reference_id,
        "action_reference": {
            "type": "storage_object",
            "storage_provider": action_reference.storage_provider,
            "storage_bucket": action_reference.storage_bucket,
            "object_key": action_reference.object_key,
            "object_version": action_reference.object_version,
        },
        "matched_reference": _matched_reference_webhook_document(
            matched_reference
        ),
    }


def storage_action_webhook_payload_bytes_v1(payload: Mapping[str, Any]) -> bytes:
    try:
        return json.dumps(
            dict(payload),
            ensure_ascii=True,
            allow_nan=False,
            separators=(",", ":"),
            sort_keys=False,
        ).encode("utf-8")
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise StorageIdentityContractError("invalid_webhook_body") from exc


def failed_webhook_reference_id(platform_id: str, outbox_id: str) -> str:
    _validate_exact_nonempty_string(platform_id, "invalid_platform_id")
    _validate_exact_nonempty_string(outbox_id, "invalid_outbox_id")
    return _deterministic_id(
        "failed-webhook:v1:",
        ["storage-failed-webhook", platform_id, outbox_id],
    )


def canonical_webhook_body_v1(payload: dict[str, Any]) -> bytes:
    """Serialize already-validated immutable webhook fields for signing."""

    try:
        rendered = json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        )
        return rendered.encode("utf-8")
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise StorageIdentityContractError("invalid_webhook_body") from exc


def _sigv4_encode(value: str, *, preserve_slash: bool) -> str:
    try:
        raw = value.encode("utf-8")
    except UnicodeEncodeError as exc:
        raise StorageIdentityContractError("invalid_sigv4_unicode") from exc
    output: list[str] = []
    for byte in raw:
        if byte in _UNRESERVED_BYTES or (preserve_slash and byte == 0x2F):
            output.append(chr(byte))
        else:
            output.append(f"%{byte:02X}")
    return "".join(output)


def canonical_s3_object_path_v1(object_key: str) -> str:
    validate_object_key(object_key)
    return "/" + _sigv4_encode(object_key, preserve_slash=True)


def decode_s3_event_object_key_v1(encoded_key: str) -> str:
    if not isinstance(encoded_key, str) or _PERCENT_ESCAPE_RE.search(encoded_key):
        raise StorageIdentityContractError("invalid_s3_event_object_key")
    try:
        decoded = unquote_to_bytes(encoded_key.replace("+", " ")).decode("utf-8")
    except UnicodeDecodeError as exc:
        raise StorageIdentityContractError("invalid_s3_event_object_key") from exc
    return validate_object_key(decoded)


def _parse_canonical_query(raw_query: str) -> dict[str, str]:
    if not raw_query:
        raise StorageIdentityContractError("missing_sigv4_query")
    parsed: dict[str, str] = {}
    for pair in raw_query.split("&"):
        if not pair or "=" not in pair:
            raise StorageIdentityContractError("invalid_sigv4_query_pair")
        raw_name, raw_value = pair.split("=", 1)
        if not raw_name or "+" in raw_name or "+" in raw_value:
            raise StorageIdentityContractError("noncanonical_sigv4_query_encoding")
        if _PERCENT_ESCAPE_RE.search(raw_name) or _PERCENT_ESCAPE_RE.search(raw_value):
            raise StorageIdentityContractError("malformed_sigv4_percent_escape")
        try:
            name = unquote_to_bytes(raw_name).decode("utf-8")
            value = unquote_to_bytes(raw_value).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise StorageIdentityContractError("invalid_sigv4_query_utf8") from exc
        if _sigv4_encode(name, preserve_slash=False) != raw_name:
            raise StorageIdentityContractError("noncanonical_sigv4_query_encoding")
        if _sigv4_encode(value, preserve_slash=False) != raw_value:
            raise StorageIdentityContractError("noncanonical_sigv4_query_encoding")
        if name in parsed:
            raise StorageIdentityContractError("duplicate_sigv4_query_parameter")
        parsed[name] = value
    return parsed


class S3SigV4BindingV1(_FrozenContractModel):
    addressing_style: Literal["virtual_hosted", "path_style"]
    endpoint_region: str | None
    credential_scope_region: str
    signed_at: datetime
    expires_seconds: int
    expires_at: datetime


def validate_s3_sigv4_binding_v1(
    *,
    presigned_url: str,
    reference: StorageObjectReferenceV1,
    integration: StorageIntegrationV1,
    now: datetime,
) -> S3SigV4BindingV1:
    """Structurally bind one transient S3 SigV4 GET URL to durable identity.

    This does not verify the AWS signature; the actual S3 GET remains signature
    authority. Errors never include the transient URL.
    """

    validate_reference_for_integration(reference, integration)
    if not isinstance(presigned_url, str) or not presigned_url.startswith("https://"):
        raise StorageIdentityContractError("invalid_s3_url_scheme")
    if any(ord(character) <= 0x20 or ord(character) == 0x7F for character in presigned_url):
        raise StorageIdentityContractError("invalid_s3_url_character")
    if "\\" in presigned_url:
        raise StorageIdentityContractError("invalid_s3_url_backslash")
    if "#" in presigned_url:
        raise StorageIdentityContractError("s3_url_fragment_forbidden")
    if _PERCENT_ESCAPE_RE.search(presigned_url):
        raise StorageIdentityContractError("malformed_sigv4_percent_escape")

    try:
        split = urlsplit(presigned_url)
    except ValueError as exc:
        raise StorageIdentityContractError("invalid_s3_url") from exc
    if split.scheme != "https" or not split.netloc or split.fragment:
        raise StorageIdentityContractError("invalid_s3_url")
    if "@" in split.netloc:
        raise StorageIdentityContractError("s3_url_userinfo_forbidden")
    if ":" in split.netloc:
        raise StorageIdentityContractError("s3_url_port_forbidden")
    try:
        split.netloc.encode("ascii")
    except UnicodeEncodeError as exc:
        raise StorageIdentityContractError("invalid_s3_hostname") from exc
    hostname = split.hostname
    if hostname is None or hostname != split.netloc or hostname.endswith("."):
        raise StorageIdentityContractError("invalid_s3_hostname")

    bucket: str
    endpoint_region: str | None
    addressing_style: Literal["virtual_hosted", "path_style"]
    expected_path: str
    regional_path_match = re.fullmatch(r"s3\.([a-z0-9-]+)\.amazonaws\.com", hostname)
    regional_virtual_match = re.fullmatch(
        r"(.+)\.s3\.([a-z0-9-]+)\.amazonaws\.com",
        hostname,
    )
    global_virtual_match = re.fullmatch(r"(.+)\.s3\.amazonaws\.com", hostname)

    canonical_key_path = canonical_s3_object_path_v1(reference.object_key)
    if hostname == "s3.amazonaws.com":
        addressing_style = "path_style"
        endpoint_region = None
        bucket = reference.storage_bucket
        expected_path = f"/{bucket}{canonical_key_path}"
    elif regional_path_match is not None:
        addressing_style = "path_style"
        endpoint_region = regional_path_match.group(1)
        bucket = reference.storage_bucket
        expected_path = f"/{bucket}{canonical_key_path}"
    elif regional_virtual_match is not None:
        addressing_style = "virtual_hosted"
        bucket = regional_virtual_match.group(1)
        endpoint_region = regional_virtual_match.group(2)
        expected_path = canonical_key_path
    elif global_virtual_match is not None:
        addressing_style = "virtual_hosted"
        bucket = global_virtual_match.group(1)
        endpoint_region = None
        expected_path = canonical_key_path
    else:
        raise StorageIdentityContractError("unsupported_s3_endpoint")

    if bucket != reference.storage_bucket:
        raise StorageIdentityContractError("storage_bucket_mismatch")
    if endpoint_region is None:
        if integration.bucket_region != "us-east-1":
            raise StorageIdentityContractError("global_s3_endpoint_region_mismatch")
    elif endpoint_region != integration.bucket_region:
        raise StorageIdentityContractError("regional_s3_endpoint_region_mismatch")
    if split.path != expected_path:
        raise StorageIdentityContractError("s3_url_path_binding_mismatch")

    query = _parse_canonical_query(split.query)
    required = {
        "X-Amz-Algorithm",
        "X-Amz-Credential",
        "X-Amz-Date",
        "X-Amz-Expires",
        "X-Amz-SignedHeaders",
        "X-Amz-Signature",
    }
    if not required.issubset(query):
        raise StorageIdentityContractError("missing_sigv4_query_parameter")
    if query["X-Amz-Algorithm"] != "AWS4-HMAC-SHA256":
        raise StorageIdentityContractError("unsupported_sigv4_algorithm")
    if not _SIGNATURE_RE.fullmatch(query["X-Amz-Signature"]):
        raise StorageIdentityContractError("invalid_sigv4_signature_shape")
    signed_headers = query["X-Amz-SignedHeaders"].split(";")
    if "host" not in signed_headers or any(not header for header in signed_headers):
        raise StorageIdentityContractError("sigv4_host_header_not_signed")

    credential_parts = query["X-Amz-Credential"].split("/")
    if (
        len(credential_parts) != 5
        or not credential_parts[0]
        or not re.fullmatch(r"[0-9]{8}", credential_parts[1])
        or not _REGION_RE.fullmatch(credential_parts[2])
        or credential_parts[3:] != ["s3", "aws4_request"]
    ):
        raise StorageIdentityContractError("invalid_sigv4_credential_scope")
    credential_region = credential_parts[2]
    if credential_region != integration.bucket_region:
        raise StorageIdentityContractError("sigv4_credential_region_mismatch")

    try:
        signed_at = datetime.strptime(query["X-Amz-Date"], "%Y%m%dT%H%M%SZ").replace(
            tzinfo=timezone.utc
        )
    except ValueError as exc:
        raise StorageIdentityContractError("invalid_sigv4_date") from exc
    if credential_parts[1] != signed_at.strftime("%Y%m%d"):
        raise StorageIdentityContractError("sigv4_credential_date_mismatch")
    expires_text = query["X-Amz-Expires"]
    if not expires_text.isdigit():
        raise StorageIdentityContractError("invalid_sigv4_expires")
    expires_seconds = int(expires_text)
    if not 1 <= expires_seconds <= 300:
        raise StorageIdentityContractError("sigv4_lifetime_out_of_range")
    if now.tzinfo is None or now.utcoffset() is None:
        raise StorageIdentityContractError("aware_now_required")
    now_utc = now.astimezone(timezone.utc)
    expires_at = signed_at + timedelta(seconds=expires_seconds)
    if expires_at <= now_utc:
        raise StorageIdentityContractError("sigv4_url_expired")
    if (expires_at - now_utc).total_seconds() < 60:
        raise StorageIdentityContractError("sigv4_insufficient_remaining_lifetime")

    version_id = query.get("versionId")
    if integration.version_policy is VersionPolicy.VERSIONED:
        if version_id is None or version_id != reference.object_version:
            raise StorageIdentityContractError("s3_url_version_binding_mismatch")
    elif version_id is not None:
        raise StorageIdentityContractError("immutable_key_version_query_forbidden")

    return S3SigV4BindingV1(
        addressing_style=addressing_style,
        endpoint_region=endpoint_region,
        credential_scope_region=credential_region,
        signed_at=signed_at,
        expires_seconds=expires_seconds,
        expires_at=expires_at,
    )


# Shield v1 is an additive pure contract. These models validate representation,
# not authority: request data cannot become a trusted profile/run by parsing it.
# The later durable loader must verify the sealed run, then server-mint a fresh
# TrustedPDQProfile. Process-local issuance and today's registry are not the
# durable authority for an older sealed profile.
SHIELD_BACKFILL_CONTRACT_VERSION = "shield_backfill_v1"
SHIELD_BACKFILL_MIGRATION_MARKER_ID = "shield_backfill_v1"
ShieldDigest = Annotated[str, Field(strict=True, pattern=r"^[0-9a-f]{64}$")]
ShieldRunID = Annotated[str, Field(strict=True, pattern=r"^shield-run:v1:[0-9a-f]{64}$")]
ShieldMode = Literal["mode_a", "mode_b"]
ShieldClassification = Literal["CLEAN", "EXACT", "FUZZY", "NEAR_MISS"]
ShieldDistance = Annotated[int, Field(strict=True, ge=0, le=256)]
ShieldOrdinalMap = Annotated[
    tuple[Annotated[int, Field(strict=True, ge=0, le=7)], ...],
    Field(min_length=8, max_length=8),
]


def shield_run_id(*, platform_id: str, client_run_id: str) -> str:
    _validate_exact_nonempty_string(platform_id, "invalid_platform_id")
    validate_backfill_client_id(client_run_id)
    return _deterministic_id("shield-run:v1:", ["shield-run:v1", platform_id, client_run_id])


def shield_corpus_id(run_id: str) -> str:
    if not isinstance(run_id, str) or re.fullmatch(r"shield-run:v1:[0-9a-f]{64}", run_id) is None:
        raise StorageIdentityContractError("invalid_shield_run_id")
    return "shield_archive:" + run_id


def _shield_digest(domain: str, projection: Sequence[Any]) -> str:
    return hashlib.sha256(canonical_json_array_v1([domain, 1, projection])).hexdigest()


class ShieldLimitsV1(_FrozenContractModel):
    """Deployment inputs, deliberately without proposed scale defaults.

    Existing registration/lease implementation bounds remain upper limits.
    Changing limits never changes an already sealed digest or its authority.
    """
    child_max_items: PositiveContractInt
    run_max_items: PositiveContractInt
    run_max_children: PositiveContractInt
    parent_manifest_max_bytes: PositiveContractInt
    registration_max_items: Annotated[int, Field(strict=True, ge=1, le=BACKFILL_REGISTRATION_PAGE_MAX_ITEMS)]
    lease_max_items: Annotated[int, Field(strict=True, ge=1, le=BACKFILL_LEASE_BATCH_MAX_ITEMS)]
    result_batch_max_items: PositiveContractInt
    result_body_max_bytes: PositiveContractInt
    worker_concurrency: PositiveContractInt
    worker_max_replicas: PositiveContractInt

    @model_validator(mode="after")
    def _bounds(self) -> "ShieldLimitsV1":
        if self.child_max_items > self.run_max_items:
            raise ValueError("shield_child_limit_exceeds_run_limit")
        return self


class ShieldStorageScopeV1(_FrozenContractModel):
    schema_version: Literal[1] = 1
    integration: StorageIntegrationV1
    approved_prefix: StrictContractStr
    selected_prefix: StrictContractStr

    @model_validator(mode="after")
    def _prefixes(self) -> "ShieldStorageScopeV1":
        for prefix in (self.approved_prefix, self.selected_prefix):
            if prefix:
                validate_object_key(prefix)
        if not self.selected_prefix.startswith(self.approved_prefix):
            raise ValueError("shield_selection_outside_approved_prefix")
        return self

    def projection(self) -> list[Any]:
        integration = self.integration
        return [integration.platform_id, integration.storage_integration_id,
                integration.configuration_version, integration.configuration_digest,
                integration.storage_provider, integration.storage_bucket,
                integration.bucket_region, integration.version_policy.value,
                self.approved_prefix, self.selected_prefix, INTEGRATION_CONTRACT_VERSION]

    @property
    def digest(self) -> str:
        return _shield_digest("shield-storage-scope:v1", self.projection())

    def validate_reference(self, reference: StorageObjectReferenceV1) -> None:
        validate_reference_for_integration(reference, self.integration)
        if not reference.object_key.startswith(self.selected_prefix):
            raise StorageIdentityContractError("shield_reference_outside_frozen_scope")


def validate_shield_scope_epoch(*, preflight_digest: str, enumeration_digest: str,
                                current_scope: ShieldStorageScopeV1) -> None:
    """Pure equality rule; authoritative lookup/run creation is a later commit."""
    for digest in (preflight_digest, enumeration_digest):
        _validated_lower_sha256(digest, "invalid_shield_scope_digest")
    if preflight_digest != enumeration_digest or current_scope.digest != preflight_digest:
        raise StorageIdentityContractError("shield_scope_epoch_changed")


class ShieldPDQLaneProfileV1(_FrozenContractModel):
    signal_family: Literal["pdq"] = "pdq"
    signal_lane: Literal["standard", "normalized"]
    algorithm_version: StrictContractStr
    model_version: None = None
    configuration_version: StrictContractStr

    @field_validator("algorithm_version", "configuration_version")
    @classmethod
    def _versions(cls, value: str) -> str:
        return _validate_exact_nonempty_string(value, "invalid_shield_profile_version")

    def projection(self) -> list[Any]:
        return [self.signal_family, self.signal_lane, self.algorithm_version,
                self.model_version, self.configuration_version]


class ShieldPDQRuntimeV1(_FrozenContractModel):
    """Sealed executable descriptor; capability verification is worker work."""
    build_id: StrictContractStr
    package_version: StrictContractStr
    native_artifact_sha256: ShieldDigest
    python_version: StrictContractStr
    platform: StrictContractStr
    architecture: StrictContractStr
    libc_version: StrictContractStr

    @field_validator("build_id", "package_version", "python_version", "platform", "architecture", "libc_version")
    @classmethod
    def _values(cls, value: str) -> str:
        return _validate_exact_nonempty_string(value, "invalid_shield_runtime_descriptor")

    def projection(self) -> list[Any]:
        return [self.build_id, self.package_version, self.native_artifact_sha256,
                self.python_version, self.platform, self.architecture, self.libc_version]


class ShieldPDQComputeProfileV1(_FrozenContractModel):
    schema_version: Literal[1] = 1
    mode: ShieldMode
    standard: ShieldPDQLaneProfileV1
    normalized: ShieldPDQLaneProfileV1
    sdk_version: StrictContractStr | None = None
    runtime: ShieldPDQRuntimeV1 | None = None

    @model_validator(mode="after")
    def _source(self) -> "ShieldPDQComputeProfileV1":
        if self.standard.signal_lane != "standard" or self.normalized.signal_lane != "normalized":
            raise ValueError("shield_profile_lane_mismatch")
        if self.mode == "mode_a":
            if self.runtime is None or self.sdk_version is not None:
                raise ValueError("shield_mode_a_runtime_required")
        elif self.sdk_version is None or self.runtime is not None:
            raise ValueError("shield_mode_b_sdk_required")
        else:
            validate_supported_sdk_version(self.sdk_version)
        return self

    @property
    def digest(self) -> str:
        return _shield_digest("shield-pdq-compute-profile:v1", [self.mode,
            self.standard.projection(), self.normalized.projection(), self.sdk_version,
            None if self.runtime is None else self.runtime.projection()])


class ShieldDetectionPolicyV1(_FrozenContractModel):
    schema_version: Literal[1] = 1
    exact: ShieldDistance
    fuzzy: ShieldDistance
    near_miss: ShieldDistance
    strict_mode: Annotated[bool, Field(strict=True)]
    normalized_exact: Literal[0] = 0
    normalized_fuzzy: Literal[15] = 15
    lane_arbitration: Literal["severity_distance_standard_tie_v1"] = "severity_distance_standard_tie_v1"
    action_interpretation: Literal["shield_live_actions_v1"] = "shield_live_actions_v1"
    historical_behavior: Literal["report_only"] = "report_only"

    @model_validator(mode="after")
    def _threshold_order(self) -> "ShieldDetectionPolicyV1":
        if not self.exact <= self.fuzzy <= self.near_miss:
            raise ValueError("shield_threshold_order_invalid")
        return self

    def classify_match(self, lane: str, distance: int) -> ShieldClassification:
        """Validate a recorded candidate against this run's frozen thresholds."""
        if type(distance) is not int or not 0 <= distance <= 256:
            raise StorageIdentityContractError("invalid_shield_match_distance")
        if lane == "normalized":
            if distance == self.normalized_exact:
                return "EXACT"
            return "FUZZY" if distance <= self.normalized_fuzzy else "CLEAN"
        if lane != "standard":
            raise StorageIdentityContractError("invalid_shield_match_lane")
        if distance <= self.exact:
            return "EXACT"
        if distance <= self.fuzzy:
            return "FUZZY"
        if distance <= self.near_miss:
            return "NEAR_MISS"
        return "CLEAN"

    def interpretation(self, raw: ShieldClassification) -> tuple[str, str, str | None]:
        if raw == "EXACT" or (raw == "FUZZY" and self.strict_mode):
            return "EXACT", "content_removed", None
        if raw == "FUZZY":
            return "FUZZY", "content_shadow_quarantined", "uploader_challenge"
        if raw == "NEAR_MISS":
            return "NEAR_MISS", "content_allowed", "threat_intelligence"
        if raw != "CLEAN":
            raise StorageIdentityContractError("invalid_shield_classification")
        return "CLEAN", "content_allowed", None

    @property
    def digest(self) -> str:
        return _shield_digest("shield-detection-policy:v1", [self.exact, self.fuzzy,
            self.near_miss, self.strict_mode, self.normalized_exact, self.normalized_fuzzy,
            self.lane_arbitration, self.action_interpretation, self.historical_behavior])


class ShieldRetentionPolicyV1(_FrozenContractModel):
    """Protect durable authority while permitting later bounded workflow cleanup.

    Run/profile/policy/scope snapshots, storage/content/signal bindings, results
    and receipt replay authorization must survive ordinary cleanup. Transient
    execution, lease, retry, journal and temporary workflow state may be cleaned
    after its recovery/audit window once it is no longer needed for recovery.
    A token or execution field still required to authenticate a durable receipt
    is retained authority, even when it resides on a workflow document.
    This contract neither schedules cleanup nor sets those future windows.
    """
    schema_version: Literal[1] = 1
    clean_receipt_expiry: None = None
    finding_expiry: None = None
    retain_signal_authority: Literal[True] = True
    retain_run_snapshots: Literal[True] = True
    workflow_cleanup_may_scrub: Literal[False] = Field(
        False, description="Ordinary workflow cleanup may not scrub durable authority; transient state is governed separately.",
    )
    transient_cleanup_policy: Literal["after_recovery_and_audit_retention_v1"] = "after_recovery_and_audit_retention_v1"
    deletion_policy: Literal["explicit_tenant_lifecycle_only_v1"] = "explicit_tenant_lifecycle_only_v1"

    @property
    def digest(self) -> str:
        return _shield_digest("shield-retention-policy:v1", [None, None, True, True, False,
            self.deletion_policy, self.transient_cleanup_policy])


class ShieldEnumerationV1(_FrozenContractModel):
    """Final customer journal summary; no S3 listing/checkpoint implementation."""
    schema_version: Literal[1] = 1
    enumeration_id: StrictContractStr
    client_run_id: StrictContractStr
    scope_digest: ShieldDigest
    version_policy: VersionPolicy
    listing_method: Literal["ListObjectVersions", "ListObjectsV2"]
    consistency: Literal["customer_quiesced_current_library_v1"] = "customer_quiesced_current_library_v1"
    quiescence_asserted: Literal[True]
    capture_started_at: datetime
    capture_completed_at: datetime
    latest_live_count: NonNegativeContractInt
    selected_identity_count: NonNegativeContractInt
    latest_delete_marker_count: NonNegativeContractInt
    noncurrent_entry_count: NonNegativeContractInt
    unresolved_identity_count: Literal[0] = 0
    current_null_version_count: Literal[0] = 0
    identity_root_digest: ShieldDigest
    # Original capture authority, retained across local re-partitioning. It is
    # part of the run intent/seal, not merely customer journal metadata.
    source_enumeration_digest: ShieldDigest | None = None

    @field_validator("enumeration_id", "client_run_id")
    @classmethod
    def _ids(cls, value: str) -> str:
        return validate_backfill_client_id(value)

    @model_validator(mode="after")
    def _complete(self) -> "ShieldEnumerationV1":
        start = format_utc_rfc3339_microseconds(self.capture_started_at)
        end = format_utc_rfc3339_microseconds(self.capture_completed_at)
        if start > end or self.latest_live_count != self.selected_identity_count:
            raise ValueError("shield_enumeration_incomplete")
        expected = "ListObjectVersions" if self.version_policy is VersionPolicy.VERSIONED else "ListObjectsV2"
        if self.listing_method != expected:
            raise ValueError("shield_enumeration_method_mismatch")
        if expected == "ListObjectsV2" and (self.latest_delete_marker_count or self.noncurrent_entry_count):
            raise ValueError("shield_unversioned_exclusions_invalid")
        if not self.selected_identity_count and self.identity_root_digest != shield_enumeration_root_digest(()):
            raise ValueError("shield_empty_enumeration_root_mismatch")
        return self

    @property
    def digest(self) -> str:
        captured = _shield_digest("shield-enumeration-summary:v1", [self.enumeration_id,
            self.client_run_id, self.scope_digest, self.version_policy.value, self.listing_method,
            self.consistency, self.quiescence_asserted,
            format_utc_rfc3339_microseconds(self.capture_started_at),
            format_utc_rfc3339_microseconds(self.capture_completed_at), self.latest_live_count,
            self.selected_identity_count, self.latest_delete_marker_count, self.noncurrent_entry_count,
            self.unresolved_identity_count, self.current_null_version_count, self.identity_root_digest])
        if self.source_enumeration_digest is None:
            return captured  # Preserve the original capture digest domain.
        return _shield_digest("shield-derived-enumeration-summary:v1",
                              [captured, self.source_enumeration_digest])


class ShieldEnumerationShardV1(_FrozenContractModel):
    client_job_id: StrictContractStr
    item_count: PositiveContractInt
    identity_digest: ShieldDigest

    @field_validator("client_job_id")
    @classmethod
    def _id(cls, value: str) -> str:
        return validate_backfill_client_id(value)


def shield_identity_digest(scope: ShieldStorageScopeV1, items: Sequence[tuple[StorageObjectReferenceV1, str | None]]) -> str:
    """Stable shard identity digest before a server run exists; exact keys."""
    entries = []
    seen = set()
    for reference, content_id in items:
        scope.validate_reference(reference)
        key = storage_identity_key(scope.integration.platform_id, reference)
        if key in seen:
            raise StorageIdentityContractError("duplicate_shield_storage_identity")
        seen.add(key)
        if content_id is not None:
            _validate_exact_nonempty_string(content_id, "invalid_platform_content_id")
        entries.append([key, reference.storage_provider, reference.storage_bucket,
                        reference.object_key, reference.object_version, content_id])
    entries.sort(key=lambda entry: entry[0].encode("utf-8"))
    return _shield_digest("shield-enumeration-identities:v1", [scope.digest, entries])


def shield_enumeration_root_digest(shards: Sequence[ShieldEnumerationShardV1]) -> str:
    ids = [shard.client_job_id for shard in shards]
    if len(set(ids)) != len(ids):
        raise StorageIdentityContractError("duplicate_shield_enumeration_shard")
    return _shield_digest("shield-enumeration-root:v1", [
        [shard.client_job_id, shard.item_count, shard.identity_digest]
        for shard in sorted(shards, key=lambda shard: shard.client_job_id.encode("utf-8"))])


class ShieldRunIntentV1(_FrozenContractModel):
    schema_version: Literal[1] = 1
    platform_id: StrictContractStr
    client_run_id: StrictContractStr
    mode: ShieldMode
    scope: ShieldStorageScopeV1
    preflight_scope_digest: ShieldDigest
    enumeration: ShieldEnumerationV1
    expected_item_count: NonNegativeContractInt
    reporting_mode: Literal["report_only"] = "report_only"

    @model_validator(mode="after")
    def _intent(self) -> "ShieldRunIntentV1":
        validate_backfill_client_id(self.client_run_id)
        if self.scope.integration.platform_id != self.platform_id:
            raise ValueError("shield_run_tenant_mismatch")
        validate_shield_scope_epoch(preflight_digest=self.preflight_scope_digest,
            enumeration_digest=self.enumeration.scope_digest, current_scope=self.scope)
        if (self.enumeration.client_run_id != self.client_run_id
                or self.enumeration.selected_identity_count != self.expected_item_count
                or self.enumeration.version_policy != self.scope.integration.version_policy):
            raise ValueError("shield_run_enumeration_mismatch")
        return self

    @property
    def run_id(self) -> str:
        return shield_run_id(platform_id=self.platform_id, client_run_id=self.client_run_id)

    @property
    def digest(self) -> str:
        return _shield_digest("shield-run-intent:v1", [self.platform_id, self.client_run_id,
            self.mode, self.scope.digest, self.preflight_scope_digest, self.enumeration.digest,
            self.expected_item_count, self.reporting_mode])

    def validate_limits(self, limits: ShieldLimitsV1) -> None:
        if self.expected_item_count > limits.run_max_items:
            raise StorageIdentityContractError("shield_run_limit_exceeded")


class ShieldChildIntentV1(_FrozenContractModel):
    schema_version: Literal[1] = 1
    platform_id: StrictContractStr
    run_id: ShieldRunID
    client_job_id: StrictContractStr
    mode: ShieldMode
    scope_digest: ShieldDigest
    expected_item_count: PositiveContractInt
    enumeration_identity_digest: ShieldDigest

    @field_validator("client_job_id")
    @classmethod
    def _id(cls, value: str) -> str:
        return validate_backfill_client_id(value)

    @property
    def job_id(self) -> str:
        return backfill_job_id(platform_id=self.platform_id, client_job_id=self.client_job_id)

    @property
    def digest(self) -> str:
        return _shield_digest("shield-child-intent:v1", [self.platform_id, self.run_id,
            self.client_job_id, self.mode, self.scope_digest, self.expected_item_count,
            self.enumeration_identity_digest])

    def validate_limits(self, limits: ShieldLimitsV1) -> None:
        if self.expected_item_count > limits.child_max_items:
            raise StorageIdentityContractError("shield_child_limit_exceeded")


def shield_child_manifest_digest(header: ShieldChildIntentV1, scope: ShieldStorageScopeV1,
                                 items: Sequence[ManifestItemV1]) -> str:
    if header.scope_digest != scope.digest or header.platform_id != scope.integration.platform_id:
        raise StorageIdentityContractError("shield_manifest_scope_mismatch")
    if len(items) != header.expected_item_count:
        raise StorageIdentityContractError("manifest_item_count_mismatch")
    for item in items:
        scope.validate_reference(item.storage_reference)
        key = storage_identity_key(header.platform_id, item.storage_reference)
        expected_id = backfill_item_id(platform_id=header.platform_id, corpus_kind="shield_archive",
            corpus_id=shield_corpus_id(header.run_id), scan_context_id=None, storage_identity_key_value=key)
        if item.storage_identity_key != key or item.item_id != expected_id:
            raise StorageIdentityContractError("shield_manifest_identity_mismatch")
    identity_digest = shield_identity_digest(scope, [(item.storage_reference, item.platform_content_id) for item in items])
    if identity_digest != header.enumeration_identity_digest:
        raise StorageIdentityContractError("shield_enumeration_registration_mismatch")
    return _shield_digest("shield-child-manifest:v1", [header.digest, _sorted_manifest_projections(items)])


class ShieldSealedChildV1(_FrozenContractModel):
    intent: ShieldChildIntentV1
    manifest_digest: ShieldDigest


class ShieldRunSealV1(_FrozenContractModel):
    """Full immutable snapshots live once on the run; item results hold digests."""
    schema_version: Literal[1] = 1
    intent: ShieldRunIntentV1
    compute_profile: ShieldPDQComputeProfileV1
    detection_policy: ShieldDetectionPolicyV1
    retention_policy: ShieldRetentionPolicyV1
    children: tuple[ShieldSealedChildV1, ...]

    @model_validator(mode="after")
    def _membership(self) -> "ShieldRunSealV1":
        if self.compute_profile.mode != self.intent.mode:
            raise ValueError("shield_run_profile_mode_mismatch")
        seen = set()
        shards = []
        for child in self.children:
            header = child.intent
            if (header.run_id != self.intent.run_id or header.platform_id != self.intent.platform_id
                    or header.mode != self.intent.mode or header.scope_digest != self.intent.scope.digest):
                raise ValueError("shield_child_run_mismatch")
            if header.job_id in seen:
                raise ValueError("duplicate_shield_child")
            seen.add(header.job_id)
            shards.append(ShieldEnumerationShardV1(client_job_id=header.client_job_id,
                item_count=header.expected_item_count, identity_digest=header.enumeration_identity_digest))
        if sum(shard.item_count for shard in shards) != self.intent.expected_item_count:
            raise ValueError("shield_run_item_count_mismatch")
        if shield_enumeration_root_digest(shards) != self.intent.enumeration.identity_root_digest:
            raise ValueError("shield_run_enumeration_root_mismatch")
        return self

    def projection(self) -> list[Any]:
        children = sorted(self.children, key=lambda child: child.intent.job_id.encode("utf-8"))
        return [self.intent.run_id, self.intent.digest, self.compute_profile.digest,
                self.detection_policy.digest, self.retention_policy.digest,
                [[child.intent.job_id, child.intent.digest, child.manifest_digest] for child in children]]

    @property
    def digest(self) -> str:
        return _shield_digest("shield-run-manifest:v1", self.projection())

    def validate_limits(self, limits: ShieldLimitsV1) -> None:
        self.intent.validate_limits(limits)
        for child in self.children:
            child.intent.validate_limits(limits)
        if len(self.children) > limits.run_max_children:
            raise StorageIdentityContractError("shield_run_children_limit_exceeded")
        if len(self.model_dump_json().encode("utf-8")) > limits.parent_manifest_max_bytes:
            raise StorageIdentityContractError("shield_parent_manifest_bytes_exceeded")


class ShieldConfirmedAuthorityV1(_FrozenContractModel):
    """Only the nine immutable fields validated by the canonical matcher.

    The digest domain/projection version is separate from Mongo schema_version.
    Operational timestamps and mutable/incidentally present fields are excluded.
    """
    document_id: StrictContractStr = Field(alias="_id")
    schema_version: Literal[2]
    confirmation_key: StrictContractStr
    hash_type: Literal["standard", "normalized"]
    hash_value: ShieldDigest
    case_id: StrictContractStr
    variant_label: Literal["canonical"]
    source: Literal["shared_confirmed_hash"]
    added_by_platform: Literal["corvinth"]

    @model_validator(mode="after")
    def _canonical(self) -> "ShieldConfirmedAuthorityV1":
        from confirmed_hash_ownership_contract import confirmation_key
        expected = confirmation_key(self.hash_type, self.hash_value)
        if not self.document_id == self.confirmation_key == self.case_id == expected:
            raise ValueError("shield_canonical_authority_mismatch")
        return self

    @property
    def digest(self) -> str:
        return _shield_digest("shield-confirmed-authority-projection:v1", [
            self.document_id, self.schema_version, self.confirmation_key, self.hash_type,
            self.hash_value, self.case_id, self.variant_label, self.source, self.added_by_platform])


def shield_confirmed_authority_projection(document: Mapping[str, Any]) -> ShieldConfirmedAuthorityV1:
    fields = ("_id", "schema_version", "confirmation_key", "hash_type", "hash_value",
              "case_id", "variant_label", "source", "added_by_platform")
    return ShieldConfirmedAuthorityV1.model_validate({field: document.get(field) for field in fields})


class ShieldPDQInputV1(_FrozenContractModel):
    """Immutable result input, not the future bulk HTTP request envelope."""
    storage_reference: StorageObjectReferenceV1
    platform_content_id: StrictContractStr | None = None
    content_sha256: ShieldDigest
    sdk_version: StrictContractStr | None
    standard: tuple[ShieldDigest, ...] = Field(min_length=8, max_length=8)
    normalized: tuple[ShieldDigest, ...] = Field(min_length=8, max_length=8)

    @field_validator("sdk_version")
    @classmethod
    def _sdk(cls, value: str | None) -> str | None:
        if value is not None:
            validate_supported_sdk_version(value)
        return value

    @field_validator("platform_content_id")
    @classmethod
    def _content_id(cls, value: str | None) -> str | None:
        return None if value is None else _validate_exact_nonempty_string(value, "invalid_platform_content_id")

    def digest(self, *, platform_id: str, profile_digest: str) -> str:
        _validated_lower_sha256(profile_digest, "invalid_shield_profile_digest")
        ref = self.storage_reference
        return _shield_digest("shield-pdq-result-input:v1", [platform_id,
            storage_identity_key(platform_id, ref), ref.storage_provider, ref.storage_bucket,
            ref.object_key, ref.object_version, self.platform_content_id, self.content_sha256,
            self.sdk_version, profile_digest, list(self.standard), list(self.normalized)])


def shield_pdq_ordinal_map(hashes: Sequence[str]) -> tuple[int, ...]:
    """Map original dihedral positions into the existing sorted signal data.

    Duplicate occurrences take successive sorted positions in original order.
    This preserves the eight inputs without duplicating their durable hashes.
    """
    if len(hashes) != 8:
        raise StorageIdentityContractError("invalid_pdq_dihedral_count")
    for value in hashes:
        _validated_lower_sha256(value, "invalid_shield_pdq_hash")
    result = [0] * 8
    for sorted_position, original_position in enumerate(sorted(range(8), key=lambda index: hashes[index])):
        result[original_position] = sorted_position
    return tuple(result)


class ShieldMatchEvidenceV1(_FrozenContractModel):
    authority: ShieldConfirmedAuthorityV1
    distance: ShieldDistance
    validated_at: datetime

    @field_validator("validated_at")
    @classmethod
    def _time(cls, value: datetime) -> datetime:
        format_utc_rfc3339_microseconds(value)
        return value

    def projection(self) -> list[Any]:
        return [self.authority.digest, self.authority.confirmation_key, self.authority.hash_type,
                self.authority.hash_value, self.authority.variant_label, self.distance,
                format_utc_rfc3339_microseconds(self.validated_at)]


class ShieldHistoricalResultV1(_FrozenContractModel):
    """Durable receipt projection; parsing does not authorize a result commit.

    The later coordinator must require finalized matcher evidence, current
    execution/parent fences for new work and verified frozen run authority.
    matcher_evidence_digest binds that execution's applied search-surface record;
    its readiness/watermark implementation is deliberately a later commit.
    """
    schema_version: Literal[1] = 1
    platform_id: StrictContractStr
    run_id: ShieldRunID
    job_id: StrictContractStr
    item_id: StrictContractStr
    execution_id: StrictContractStr
    attempt_generation: PositiveContractInt
    run_manifest_digest: ShieldDigest
    child_manifest_digest: ShieldDigest
    scope_digest: ShieldDigest
    compute_profile_digest: ShieldDigest
    detection_policy_digest: ShieldDigest
    retention_policy_digest: ShieldDigest
    input_digest: ShieldDigest
    content_sha256: ShieldDigest
    standard_binding_id: StrictContractStr
    standard_signal_fingerprint: StrictContractStr
    normalized_binding_id: StrictContractStr
    normalized_signal_fingerprint: StrictContractStr
    standard_ordinal_map: ShieldOrdinalMap
    normalized_ordinal_map: ShieldOrdinalMap
    content_binding_provenance: Literal["corvinth_computed", "platform_asserted"]
    binding_method: Literal["signed_exact_version_response", "immutable_key_policy_fetch", "sdk_storage_reference_assertion"]
    binding_validated_at: datetime
    raw_classification: ShieldClassification
    effective_classification: ShieldClassification
    recommended_action: Literal["content_removed", "content_shadow_quarantined", "content_allowed"]
    review_queue: Literal["uploader_challenge", "threat_intelligence"] | None
    match: ShieldMatchEvidenceV1 | None
    matcher_evidence_digest: ShieldDigest
    match_completed_at: datetime
    committed_at: datetime
    report_only: Literal[True] = True

    @field_validator("standard_ordinal_map", "normalized_ordinal_map")
    @classmethod
    def _ordinal_map(cls, value: tuple[int, ...]) -> tuple[int, ...]:
        if sorted(value) != list(range(8)):
            raise ValueError("shield_ordinal_map_must_be_permutation")
        return value

    @model_validator(mode="after")
    def _evidence(self) -> "ShieldHistoricalResultV1":
        for value in (self.platform_id, self.job_id, self.item_id, self.execution_id,
                      self.standard_binding_id, self.standard_signal_fingerprint,
                      self.normalized_binding_id, self.normalized_signal_fingerprint):
            _validate_exact_nonempty_string(value, "invalid_shield_result_identity")
        if self.execution_id != backfill_execution_id(
            platform_id=self.platform_id, job_id=self.job_id, item_id=self.item_id,
            attempt_generation=self.attempt_generation,
        ):
            raise ValueError("shield_result_execution_identity_mismatch")
        for value in (self.binding_validated_at, self.match_completed_at, self.committed_at):
            format_utc_rfc3339_microseconds(value)
        if self.binding_validated_at > self.match_completed_at or self.match_completed_at > self.committed_at:
            raise ValueError("shield_result_time_order_invalid")
        if (self.raw_classification == "CLEAN") != (self.match is None):
            raise ValueError("shield_result_match_evidence_mismatch")
        if self.match is not None and self.match.validated_at > self.match_completed_at:
            raise ValueError("shield_result_validation_time_invalid")
        asserted = self.binding_method == "sdk_storage_reference_assertion"
        if asserted != (self.content_binding_provenance == "platform_asserted"):
            raise ValueError("shield_result_binding_provenance_mismatch")
        return self

    @property
    def digest(self) -> str:
        # Explicit immutable projection; never hash arbitrary Mongo document data.
        return _shield_digest("shield-historical-result:v1", [self.platform_id, self.run_id,
            self.job_id, self.item_id, self.execution_id, self.attempt_generation,
            self.run_manifest_digest, self.child_manifest_digest, self.scope_digest,
            self.compute_profile_digest, self.detection_policy_digest, self.retention_policy_digest,
            self.input_digest, self.content_sha256, self.standard_binding_id,
            self.standard_signal_fingerprint, self.normalized_binding_id, self.normalized_signal_fingerprint,
            list(self.standard_ordinal_map), list(self.normalized_ordinal_map),
            self.content_binding_provenance, self.binding_method,
            format_utc_rfc3339_microseconds(self.binding_validated_at), self.raw_classification,
            self.effective_classification, self.recommended_action, self.review_queue,
            None if self.match is None else self.match.projection(), self.matcher_evidence_digest,
            format_utc_rfc3339_microseconds(self.match_completed_at),
            format_utc_rfc3339_microseconds(self.committed_at), self.report_only])

    def validate_run(self, run: ShieldRunSealV1) -> None:
        if (self.platform_id != run.intent.platform_id or self.run_id != run.intent.run_id
                or self.run_manifest_digest != run.digest or self.scope_digest != run.intent.scope.digest
                or self.compute_profile_digest != run.compute_profile.digest
                or self.detection_policy_digest != run.detection_policy.digest
                or self.retention_policy_digest != run.retention_policy.digest):
            raise StorageIdentityContractError("shield_result_run_authority_mismatch")
        children = [child for child in run.children if child.intent.job_id == self.job_id]
        if len(children) != 1 or children[0].manifest_digest != self.child_manifest_digest:
            raise StorageIdentityContractError("shield_result_child_authority_mismatch")
        if self.match is not None and self.raw_classification != run.detection_policy.classify_match(
            self.match.authority.hash_type, self.match.distance
        ):
            raise StorageIdentityContractError("shield_result_classification_mismatch")
        if (self.effective_classification, self.recommended_action, self.review_queue) != run.detection_policy.interpretation(self.raw_classification):
            raise StorageIdentityContractError("shield_result_policy_mismatch")
        if (run.intent.mode == "mode_b") != (self.binding_method == "sdk_storage_reference_assertion"):
            raise StorageIdentityContractError("shield_result_mode_mismatch")
        if run.intent.mode == "mode_a":
            expected = ("signed_exact_version_response" if run.intent.scope.integration.version_policy is VersionPolicy.VERSIONED
                        else "immutable_key_policy_fetch")
            if self.binding_method != expected:
                raise StorageIdentityContractError("shield_result_version_binding_mismatch")
