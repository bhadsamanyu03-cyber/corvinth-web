"""Customer-owned S3 connector. No customer AWS credentials go to Corvinth.

Run continuously with customer S3 access and a tenant integration API key in the
environment. The admin's logical intent is polled/claimed; no manifest/job IDs
or fetch URLs need copying. Journals require durable local SQLite storage.
"""
import argparse
import json
import os
import re
from pathlib import Path
import sqlite3
import time
from types import SimpleNamespace
from urllib.parse import quote
import uuid

import boto3
from botocore.config import Config
import httpx

import logical_s3_contract as sc
import storage_identity_contract as contract
from pulse_s3_listing import normalize_page


class ConnectorError(RuntimeError):
    pass


class ConnectorTransportError(ConnectorError):
    def __init__(self, diagnostic):
        self.diagnostic = diagnostic
        super().__init__('connector_transport_' + diagnostic['acceptance'])


def operation(path):
    """Fixed operation names, never URL/query/body/header values."""
    value = path.split('?', 1)[0].rsplit('/', 1)[-1]
    return value if value in {'claim', 'pages', 'seal', 'compute-claim', 'leases',
        'admitted', 'executions', 'execution-status'} else 'readback'


def transport_detail(exc):
    chain = []; seen = set()
    while exc is not None and id(exc) not in seen and len(chain) < 8:
        seen.add(id(exc)); row = {'class': type(exc).__name__}
        code = getattr(exc, 'errno', None)
        if type(code) is int:
            row.update(errno=code, errno_description=os.strerror(code))
        for name in ('verify_code', 'library', 'reason'):
            value = getattr(exc, name, None)
            if type(value) is int or (isinstance(value, str) and re.fullmatch(r'[A-Z0-9_]{1,80}', value)):
                row[name] = value
        # Some httpcore wrappers retain only this fixed aggregate message.
        if str(exc) == 'All connection attempts failed':
            row['detail'] = 'all_connection_attempts_failed'
        chain.append(row); exc = exc.__cause__ or exc.__context__
    return chain


class Transport:
    """One connect-only recovery; original 90s budget covers both attempts.

    Request tracing records event names only. Starting header transmission is
    conservatively ambiguous even if no bytes ultimately reach the peer.
    """
    TIMEOUT_SECONDS = 90
    MAX_ATTEMPTS = 2

    def __init__(self, client, *, evidence=lambda value: None, sleep=time.sleep, clock=time.monotonic):
        self.client, self.evidence, self.sleep, self.clock = client, evidence, sleep, clock

    def __call__(self, method, path, body=None):
        deadline = self.clock() + self.TIMEOUT_SECONDS
        for attempt in range(1, self.MAX_ATTEMPTS + 1):
            events = []
            def trace(name, info):
                if re.fullmatch(r'[a-zA-Z0-9_.]{1,100}', name): events.append(name)
            remaining = deadline - self.clock()
            if remaining <= 0: raise ConnectorError('connector_transport_budget_exhausted')
            try:
                response = self.client.request(method, path, json=body, timeout=remaining,
                    extensions={'trace': trace})
            except httpx.TransportError as exc:
                sent = any('send_request_headers' in name or 'send_request_body' in name for name in events)
                pre = isinstance(exc, (httpx.ConnectError, httpx.ConnectTimeout, httpx.PoolTimeout)) and not sent
                retry = pre and attempt < self.MAX_ATTEMPTS and deadline - self.clock() > .25
                detail = dict(schema='pulse-connector-transport:v1', operation=operation(path),
                    method=method, attempt=attempt, max_attempts=self.MAX_ATTEMPTS,
                    stage=events[-1] if events else 'connection_or_pool' if pre else 'unobserved_transport',
                    transmission='not_started' if pre else 'started_or_unknown',
                    acceptance='not_accepted' if pre else 'ambiguous', retry_scheduled=retry,
                    trace_events=events[-12:], causes=transport_detail(exc))
                self.evidence(detail)
                if not retry: raise ConnectorTransportError(detail) from None
                self.sleep(.25)
                continue
            if attempt > 1:
                self.evidence(dict(schema='pulse-connector-recovery:v1', operation=operation(path),
                    attempt=attempt, status_code=response.status_code, recovered=True))
            if response.status_code >= 400:
                code = 'unspecified'
                try:
                    value = response.json().get('detail', {}).get('error_code')
                    if isinstance(value, str) and re.fullmatch(r'[a-z0-9_]{1,100}', value): code = value
                except (ValueError, AttributeError, TypeError): pass
                detail=dict(schema='pulse-connector-http-error:v1', operation=operation(path),
                    attempt=attempt, status_code=response.status_code, error_code=code,
                    transmission='response_received',
                    acceptance='ambiguous' if method != 'GET' and response.status_code>=500 else 'response_received',
                    retry_scheduled=False)
                self.evidence(detail)
                if detail['acceptance']=='ambiguous':raise ConnectorTransportError(detail) from None
                raise ConnectorError('api_request_rejected_' + str(response.status_code) + '_' + code)
            return response.json()


def encoded(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'))


class Journal:
    def __init__(self,path,intent):
        path=Path(path)
        if not path.exists():
            fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.close(fd)
        self.db=sqlite3.connect(path,isolation_level=None,timeout=30)
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''CREATE TABLE IF NOT EXISTS intent(value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS pages(number INTEGER PRIMARY KEY,input_cursor TEXT NOT NULL,
                output_cursor TEXT NOT NULL,page TEXT NOT NULL,ack INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS executions(item_id TEXT NOT NULL,generation INTEGER NOT NULL,
                accepted INTEGER NOT NULL,PRIMARY KEY(item_id,generation));''')
        row=self.db.execute('SELECT value FROM intent').fetchone()
        if row and row[0]!=encoded(intent):raise ConnectorError('journal_scope_or_origin_changed')
        if not row:self.db.execute('INSERT INTO intent VALUES(?)',(encoded(intent),))

    def page_state(self):
        row=self.db.execute('SELECT number,output_cursor,page,ack FROM pages ORDER BY number DESC LIMIT 1').fetchone()
        return (row[0]+1,json.loads(row[1]),json.loads(row[2])['complete']) if row else (0,{},False)

    def pending(self):
        row=self.db.execute('SELECT number,page FROM pages WHERE ack=0 ORDER BY number LIMIT 1').fetchone()
        return json.loads(row[1]) if row else None

    def record(self,input_cursor,page):
        number=self.page_state()[0]
        transport=dict(number=number,input_cursor_digest=sc.digest(input_cursor),
            output_cursor_digest=sc.digest(page['next_cursor']),complete=page['complete'],entries=page['entries'])
        self.db.execute('BEGIN IMMEDIATE')
        try:
            self.db.execute('INSERT INTO pages VALUES(?,?,?,?,0)',
                (number,encoded(input_cursor),encoded(page['next_cursor']),encoded(transport)))
            self.db.commit()
        except BaseException:self.db.rollback();raise
        return transport

    def ack(self,number):self.db.execute('UPDATE pages SET ack=1 WHERE number=?',(number,))
    def chain_digest(self,through):
        chain=sc.digest([])
        for row in self.db.execute('SELECT page FROM pages WHERE number<=? ORDER BY number',(through,)):
            chain=sc.digest([chain,sc.digest(json.loads(row[0]))])
        return chain
    def close(self):self.db.close()


class Connector:
    def __init__(self,*,s3,api,api_origin,journal_root,integration_id,prefix,connector_id,page_size=100):
        if not 1<=page_size<=100:raise ConnectorError('page_size_out_of_bound')
        self.s3,self.api=s3,api
        self.origin,self.root=api_origin,Path(journal_root)
        self.root.mkdir(parents=True,exist_ok=True)
        self.integration_id,self.prefix=integration_id,prefix
        self.connector_id=str(uuid.UUID(connector_id));self.page_size=page_size
        self.metrics={'pages':0,'presigns':0,'execution_submissions':0,'claimed_scans':[],
            'execution_reconciliations':0,'page_reconciliations':0}

    def post(self,path,body):return self.api('POST',path,body)

    def claim(self):
        return self.post('/v2/pulse/connectors/historical-scans/claim',dict(
            storage_integration_id=self.integration_id,selected_prefix=self.prefix,connector_id=self.connector_id))

    def capture(self,claim,*,stop_after_pages=None):
        scan=claim['scan_id'];scope=contract.ShieldStorageScopeV1.model_validate(claim['scope'])
        method='ListObjectVersions' if scope.integration.version_policy is contract.VersionPolicy.VERSIONED else 'ListObjectsV2'
        status=self.s3.get_bucket_versioning(Bucket=scope.integration.storage_bucket).get('Status','Unversioned')
        if status not in {'Enabled','Suspended','Unversioned'} or (method=='ListObjectVersions' and status=='Unversioned'):
            raise ConnectorError('bucket_versioning_incompatible')
        intent=dict(schema='customer-pulse-captured-traversal:v1',scan_id=scan,scope=claim['scope'],
            api_origin=self.origin,connector_id=self.connector_id,listing_method=method,versioning=status,page_size=self.page_size)
        journal=Journal(self.root/(scan+'.sqlite'),intent)
        path='/v2/pulse/connectors/historical-scans/'+scan
        try:
            sent=0
            while True:
                pending=journal.pending()
                if pending is None:
                    number,cursor,complete=journal.page_state()
                    if complete:break
                    args=dict(Bucket=scope.integration.storage_bucket,Prefix=scope.selected_prefix,
                        MaxKeys=self.page_size,EncodingType='url',**cursor)
                    response=(self.s3.list_object_versions if method=='ListObjectVersions' else self.s3.list_objects_v2)(**args)
                    page=normalize_page(SimpleNamespace(scope=scope,listing_method=method),response,self.page_size)
                    pending=journal.record(cursor,page)
                # Reconcile the durable page/cursor chain through the existing
                # claim fence before sending a journaled page, including resume.
                fresh=self.claim()
                if not fresh or fresh['scan_id']!=scan:raise ConnectorError('discovery_claim_changed')
                d=fresh['discovery'];number=pending['number']
                if d['pages']==number+1:
                    if (d['chain_digest']!=journal.chain_digest(number)
                            or d['cursor_digest']!=pending['output_cursor_digest']
                            or d['listed']!=pending['complete']):
                        raise ConnectorError('discovery_page_readback_conflict')
                    self.metrics['page_reconciliations']+=1
                elif (d['pages']==number and d['chain_digest']==journal.chain_digest(number-1)
                        and d['cursor_digest']==pending['input_cursor_digest']
                        and d['status'] in {'pending','enumerating'} and not d['listed']):
                    # Same exact digest-bound page, resolved by the existing
                    # transactional replay/unique-page rule; never rediscover or
                    # manufacture a cursor after ambiguous remote acceptance.
                    ack=self.post(path+'/pages',dict(connector_id=self.connector_id,page=pending))
                    if not ack.get('acknowledged'):raise ConnectorError('page_not_acknowledged')
                else:raise ConnectorError('discovery_page_readback_conflict')
                journal.ack(pending['number']);self.metrics['pages']+=1;sent+=1
                if stop_after_pages and sent>=stop_after_pages:return {'interrupted_after_durable_page':True,'scan_id':scan}
            return self.post(path+'/seal',dict(connector_id=self.connector_id))
        finally:journal.close()

    def execute_one(self,scan,job,*,on_lease=None):
        path='/v2/pulse/connectors/historical-scans/'+scan+'/compute/'+quote(job['job_id'],safe='')
        leases=self.post(path+'/leases',dict(connector_id=self.connector_id))
        for lease in leases:
            if on_lease is not None: on_lease(lease)
            until=min(time.time()+40,time.time()+max(0,180-20))
            while time.time()<until:
                admitted=self.post(path+'/admitted',dict(connector_id=self.connector_id,
                    item_id=lease['item_id'],attempt_generation=lease['attempt_generation']))
                if admitted['admitted']:break
                time.sleep(.5)
            else:raise ConnectorError('controller_did_not_admit_lease')
            ref=lease['storage_reference'];params=dict(Bucket=ref['storage_bucket'],Key=ref['object_key'])
            if ref.get('object_version') is not None:params['VersionId']=ref['object_version']
            # This is the sole presign site: after compute lease AND controller admission.
            url=self.s3.generate_presigned_url('get_object',Params=params,ExpiresIn=300)
            self.metrics['presigns']+=1
            try:
                self.post(path+'/executions',dict(connector_id=self.connector_id,execution=dict(
                    backfill_job_id=job['job_id'],item_id=lease['item_id'],attempt_generation=lease['attempt_generation'],
                    lease_token=lease['lease_token'],ephemeral_storage_reference=ref,presigned_url=url)))
            except ConnectorTransportError as exc:
                if exc.diagnostic['acceptance'] != 'ambiguous': raise
                # No POST replay. Observe exact durable execution identity/attempt.
                status = self.post(path+'/execution-status',dict(connector_id=self.connector_id,
                    item_id=lease['item_id'],attempt_generation=lease['attempt_generation']))
                if not status['accepted']:
                    # Absence is not proof of rejection: never resubmit on a racing read.
                    raise ConnectorError('execution_acceptance_unresolved_requires_authoritative_fencing') from None
                self.metrics['execution_reconciliations'] += 1
            self.metrics['execution_submissions']+=1
        return len(leases)

    def tick(self,*,discover_only=False,stop_after_pages=None):
        claim=self.claim()
        if not claim:return None
        scan=claim['scan_id']
        if scan not in self.metrics['claimed_scans']:self.metrics['claimed_scans'].append(scan)
        if claim['discovery']['status']!='sealed':
            result=self.capture(claim,stop_after_pages=stop_after_pages)
            if result.get('interrupted_after_durable_page'):return result
        if discover_only:return {'scan_id':scan,'discovery_sealed':True}
        plan=self.post('/v2/pulse/connectors/historical-scans/'+scan+'/compute-claim',dict(connector_id=self.connector_id))
        for job in plan['children']:
            if job['status']=='active' and job['activation_admission']=='OPEN':
                self.execute_one(scan,job)
                break
        return {'scan_id':scan,'ready':plan['ready']}


def main():
    p=argparse.ArgumentParser()
    for name in ['api-origin','journal-root','integration-id','prefix','connector-id']:p.add_argument('--'+name,required=True)
    p.add_argument('--aws-profile');p.add_argument('--once',action='store_true');p.add_argument('--discover-only',action='store_true')
    a=p.parse_args()
    if not a.api_origin.startswith('https://'):raise ConnectorError('https_required')
    key=os.environ['CORVINTH_API_KEY']
    session=boto3.Session(profile_name=a.aws_profile,region_name='us-east-1')
    s3=session.client('s3',config=Config(signature_version='s3v4',connect_timeout=5,read_timeout=30,
        retries={'total_max_attempts':2}))
    with httpx.Client(base_url=a.api_origin,headers={'x-api-key':key},timeout=90,trust_env=False,follow_redirects=False) as hc:
        def report(value): print(json.dumps(value, sort_keys=True), flush=True)
        api=Transport(hc,evidence=report)
        connector=Connector(s3=s3,api=api,api_origin=a.api_origin,journal_root=a.journal_root,
            integration_id=a.integration_id,prefix=a.prefix,connector_id=a.connector_id)
        while True:
            try: connector.tick(discover_only=a.discover_only)
            except BaseException as exc:
                report(dict(schema='pulse-connector-stopped:v1',stage='tick',
                    error_class=type(exc).__name__,causes=transport_detail(exc),
                    action='stop_new_requests_and_reconcile_authority'))
                raise SystemExit(1) from None
            if a.once:break
            time.sleep(1)
    print(json.dumps(connector.metrics))

if __name__=='__main__':main()
