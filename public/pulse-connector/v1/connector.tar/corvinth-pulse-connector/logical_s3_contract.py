"""Additive settled-work contract. It does not redefine all-success drain."""
import hashlib
import json

CONTRACT = 'logical-s3-settled:v1'
SCHEMA = 'aws-dino-logical-s3-settled-drain:v1'
MODE = 'customer_s3_compute'
MAX_COMPUTE = 100
TERMINAL = {'completed', 'failed', 'cancelled'}
EXECUTION_TERMINAL = {'completed', 'terminal_failed', 'cancelled', 'superseded', 'retryable_failed'}
ZERO_FIELDS = ('pending', 'inflight', 'retrying', 'unpublished', 'unknown')
BINDING_FIELDS = ('job_id', 'platform_id', 'job_manifest_digest', 'expected_count',
                  'logical_scan_id', 'logical_manifest_digest', 'settlement_contract')


class SettlementError(RuntimeError):
    pass


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def outcome(counts):
    return ('settled_with_failures' if counts['failed'] else
            'settled_cancelled' if counts['cancelled'] else 'all_success')


def validate_receipt(receipt, binding, image, profile):
    """Validate identity/counts without turning failed outcomes into successes."""
    if not isinstance(receipt, dict) or receipt.get('schema') != SCHEMA:
        raise SettlementError('logical_s3_receipt_invalid')
    if receipt.get('settlement_contract') != CONTRACT or binding.get('settlement_contract') != CONTRACT:
        raise SettlementError('logical_s3_contract_mismatch')
    for key in ('run_id', 'generation', 'manifest_sha256', *BINDING_FIELDS):
        if receipt.get(key) != binding.get(key):
            raise SettlementError('logical_s3_binding_mismatch')
    if (receipt.get('image') != image or receipt.get('profile') != profile
            or receipt.get('admission') != 'CLOSED' or receipt.get('safe_to_teardown') is not True):
        raise SettlementError('logical_s3_receipt_invalid')
    expected = receipt.get('expected_count')
    rows = receipt.get('records')
    if (type(expected) is not int or not 1 <= expected <= MAX_COMPUTE
            or not isinstance(rows, list) or len(rows) != expected):
        raise SettlementError('logical_s3_membership_mismatch')
    ids, counts = set(), dict(completed=0, failed=0, cancelled=0)
    for row in rows:
        if (not isinstance(row, dict) or not isinstance(row.get('item_id'), str)
                or row['item_id'] in ids or row.get('status') not in TERMINAL):
            raise SettlementError('logical_s3_membership_mismatch')
        ids.add(row['item_id']); counts[row['status']] += 1
        if row.get('execution_mode') != MODE or not isinstance(row.get('terminal_digest'), str):
            raise SettlementError('logical_s3_terminal_authority_mismatch')
        if row['status'] != 'completed' and not row.get('error_code'):
            raise SettlementError('logical_s3_terminal_authority_mismatch')
        if row['status'] == 'completed' and not row.get('publication_verified'):
            raise SettlementError('logical_s3_publication_not_settled')
    supplied_counts = receipt.get('counts')
    if (not isinstance(supplied_counts, dict) or set(supplied_counts) != set(counts)
            or any(type(supplied_counts[k]) is not int for k in counts)
            or supplied_counts != counts or sum(counts.values()) != expected
            or any(type(receipt.get(k)) is not int or receipt[k] != 0 for k in ZERO_FIELDS)
            or receipt.get('outcome') != outcome(counts)):
        raise SettlementError('logical_s3_unfinished_work')
    unsigned = {k: v for k, v in receipt.items() if k != 'receipt_sha256'}
    if receipt.get('receipt_sha256') != digest(unsigned):
        raise SettlementError('logical_s3_receipt_digest_mismatch')
    return counts


# Capacity lifetime is additive and distinct from the unchanged bounded-child
# settlement above. Reuse never belongs to this compute activation membership.
WARM_CONTRACT = 'logical-s3-warm-settled:v1'
WARM_SCHEMA = 'aws-dino-logical-s3-warm-drain:v1'
WARM_FIELDS = ('platform_id', 'logical_scan_id', 'logical_manifest_digest',
               'compute_children', 'expected_count', 'settlement_contract')


def validate_warm_scope(scope):
    if (set(scope) != set(WARM_FIELDS) or scope.get('settlement_contract') != WARM_CONTRACT
            or not all(isinstance(scope.get(k), str) and scope[k] for k in
                       ('platform_id', 'logical_scan_id', 'logical_manifest_digest'))):
        raise SettlementError('warm_scope_invalid')
    children = scope['compute_children']
    if (not isinstance(children, list) or not children or len(children) > 50
            or len({c.get('job_id') for c in children}) != len(children)
            or any(set(c) != {'job_id', 'manifest_digest', 'expected_count'}
                   or not all(isinstance(c[k], str) and c[k] for k in ('job_id', 'manifest_digest'))
                   or type(c['expected_count']) is not int or not 1 <= c['expected_count'] <= MAX_COMPUTE
                   for c in children)
            or type(scope['expected_count']) is not int
            or scope['expected_count'] != sum(c['expected_count'] for c in children)
            or not 1 <= scope['expected_count'] <= 5000):
        raise SettlementError('warm_membership_mismatch')
    return children


def warm_child_index(scope, binding):
    children = validate_warm_scope(scope)
    if (binding.get('settlement_contract') != CONTRACT
            or any(binding.get(k) != scope[k] for k in
                   ('platform_id', 'logical_scan_id', 'logical_manifest_digest'))):
        raise SettlementError('warm_child_binding_mismatch')
    matches = [n for n, c in enumerate(children) if c['job_id'] == binding.get('job_id')
               and c['manifest_digest'] == binding.get('job_manifest_digest')
               and c['expected_count'] == binding.get('expected_count')]
    if len(matches) != 1:
        raise SettlementError('warm_child_binding_mismatch')
    return matches[0]


def validate_warm_receipt(receipt, binding, image, profile):
    scope = {k: binding[k] for k in WARM_FIELDS}
    children = validate_warm_scope(scope)
    if (receipt.get('schema') != WARM_SCHEMA or receipt.get('image') != image
            or receipt.get('profile') != profile or receipt.get('admission') != 'CLOSED'
            or receipt.get('safe_to_teardown') is not True
            or any(receipt.get(k) != binding.get(k) for k in ('run_id', 'generation', 'manifest_sha256', *WARM_FIELDS))
            or any(type(receipt.get(k)) is not int or receipt[k] != 0 for k in ZERO_FIELDS)):
        raise SettlementError('warm_receipt_invalid')
    refs = receipt.get('child_receipts')
    if not isinstance(refs, list) or len(refs) != len(children):
        raise SettlementError('warm_children_unsettled')
    counts = dict(completed=0, failed=0, cancelled=0)
    for child, ref in zip(children, refs):
        if (any(ref.get(k) != child[k] for k in child)
                or not isinstance(ref.get('receipt_sha256'), str) or len(ref['receipt_sha256']) != 64
                or set(ref.get('counts', {})) != set(counts)
                or any(type(v) is not int or v < 0 for v in ref['counts'].values())
                or sum(ref['counts'].values()) != child['expected_count']):
            raise SettlementError('warm_children_unsettled')
        for k in counts: counts[k] += ref['counts'][k]
    if (receipt.get('counts') != counts or receipt.get('outcome') != outcome(counts)
            or not receipt.get('logical_completion_digest')
            or receipt.get('receipt_sha256') != digest({k:v for k,v in receipt.items() if k != 'receipt_sha256'})):
        raise SettlementError('warm_receipt_invalid')
    return counts
